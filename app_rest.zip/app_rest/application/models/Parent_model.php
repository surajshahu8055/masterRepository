<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Parent_model extends MY_Model {
    public function __construct() {
        parent::__construct();
    }
    public function check_login() {
        $login = $_SESSION['logged_in'];
        $role = $_SESSION['user_role'];
        if ($login == TRUE && $role == 'parents') {
            return 1;
        } else {
            return 0;
        }
    }
	
	public function get_class_section($student_id) {
        $query = $this->db->select('st_class,section,academic_year,admission_date')->from('student_basic_details')->where('student_id', $student_id)->get()->row();
        return $query;
    }
	
    public function get_class_student($student_id) {
        $query = $this->db->select('st_class as class')->from('student_basic_details')->where('student_id', $student_id)->get()->row();
        return $query;
    }
	
	public function monthwise_attendance($student_id){
       return $this->db->query("SELECT YEAR(`attendance_date`) AS y, MONTH(`attendance_date`) AS m, COUNT(DISTINCT `attendance_id`) AS days FROM `student_attendance` WHERE `present_student_id` LIKE '%$student_id%' GROUP BY y, m ORDER BY y,m DESC LIMIT 12")->result_array();
    }

    public function monthwise_working_days($class,$section){
       return $this->db->query("SELECT YEAR(`attendance_date`) AS y, MONTH(`attendance_date`) AS m, COUNT(DISTINCT `attendance_id`) AS days FROM `student_attendance` WHERE `stu_class` ='$class' AND `class_section` = '$section'  GROUP BY y, m ORDER BY y,m DESC LIMIT 12")->result_array();
    }
	
	
	

    public function get_attendance_count($student_id) {
      
        $year = date('Y');
        $month = date('m');
        $where = "MONTH(attendance_date) = $month AND YEAR(attendance_date) = $year";
        $this->db->select('*');
        $this->db->from('student_attendance');
        $this->db->where($where);
        $this->db->like('present_student_id', $student_id);
        $query = $this->db->get();
        return $query->num_rows();
    }
    public function get_working_days_count($student_id) {
        $year = date('Y');
        $month = date('m');
        $where = "MONTH(attendance_date) = $month AND YEAR(attendance_date) = $year";
        $this->db->select('*');
        $this->db->from('student_attendance');
        $this->db->where($where);
        $query = $this->db->get();
        return $query->num_rows();
    }
    public function get_attendance() {
        $student_id = $_SESSION['user_id'];
        $year = date('Y');
        $month = date('m');
        $where = "MONTH(attendance_date) = $month AND YEAR(attendance_date) = $year";
        $this->db->select('*');
        $this->db->from('student_attendance');
        $this->db->where($where);
        $this->db->like('present_student_id', $student_id);
        $query = $this->db->get();
        return $query->result_array();
    }
    public function get_fees_record_student($student_id) {
       
        $query = $this->db->get_where('student_fees', array('student_id' => $student_id,'academic_year' => $_SESSION['academic_year']));
        return $query->result_array();
    }
    public function get_total_school_fees($student_id) {
        $data = $this->get_class_section($student_id);
        $class = $data->st_class;
        $academic_year = $data->academic_year;
        $query = $this->db->get_where('school_fees', array('fees_class' => $class, 'academic_year' => $academic_year));
        $result = $query->row();
        
        $this->db->select('student_id,is_sibling,sibling_id');
        $this->db->from('student_profile');
        $this->db->where('student_id', $student_id);
        $result_2 = $this->db->get()->row_array();
        $this->db->select('student_basic_details.first_name,student_basic_details.middle_name,last_name,users.user_id');
        $this->db->from('student_basic_details');
        $this->db->join('users', 'student_basic_details.student_id=users.user_id', 'left');
        $this->db->where('student_id', $student_id);
        $this->db->where('users.status', 'active');
        $this->db->where('users.role', 'parents');
        $result1 = $this->db->get()->row_array();
        $middle_name = $result1['middle_name'];
        $last_name = $result1['last_name'];
        $sibling_count = $this->get_sibling_count($middle_name, $last_name);
        if(date('Y', strtotime($data->admission_date)) == date('Y', strtotime($_SESSION['sch_start_date']))){
            if($result_2['is_sibling'] == 'child') {
                return $result->total_school_fees - $result->security_deposit;
            } else {
                return $result->total_school_fees;
            }
        }else{
            return $result->total_school_fees - $result->security_deposit - $result->admission_fees - $result->development_fees;;
        }
        
    }
    public function get_total_fees_paid($student_id) {
        //$student_id = $_SESSION['user_id'];
        $this->db->select('SUM(fees_amount) AS total_paid_fees');
        $query = $this->db->get_where('student_fees', array('student_id' => $student_id));
        $result = $query->row();
        return $result->total_paid_fees;
    }
    public function get_exam_time_table() {
        $data = $this->get_class_section();
        $class = $data->st_class;
        $query = $this->db->get_where('exam_time_table', array('time_table_class' => $class));
        return $query->result_array();
    }
    public function get_class_time_table() {
        $data = $this->get_class_section();
        $class = $data->st_class;
        $section = $data->section;
        $query = $this->db->get_where('class_time_table', array('ttclass' => $class, 'section' => $section));
        return $query->result_array();
    }
    
    public function day_wise_time_table($student_id, $day){
        $this->db->select('st_class,section');
        $this->db->from('student_basic_details');
        $this->db->where('student_id',$student_id);
        $query = $this->db->get()->row();
        
        $this->db->select("$day,time");
        $this->db->from('class_time_table');
        $where = array('ttclass' =>$query->st_class, 'section'=> $query->section);
        $this->db->where($where);
        $query = $this->db->get()->result_array();
		$data = Array();
		foreach($query as $temp){
			$data[] = array(	
				'subject' => $temp[$day],
				'time' => $temp['time']
			);
		}
        return $data;
    }
    
    public function get_student_result() {
		$data = $this->get_class_section();
        $class = $data->st_class;
        $student_id = $_SESSION['user_id'];
        $query = $this->db->get_where('result_academic', array('studentid' => $student_id,'class'=> $class));
		$check_student = $query->num_rows();
        if ($check_student > 0) {
            return $query->result_array();
        } else {
            return 'false';
        }
    }
	
    public function get_student_grade() {
		$data = $this->get_class_section();
        $class = $data->st_class;
        $student_id = $_SESSION['user_id'];
        $query = $this->db->get_where('result_extra', array('studentid' => $student_id,'class'=> $class));
		$check_student = $query->num_rows();
        if ($check_student > 0) {
            return $query->result_array();
        } else {
            return 'false';
        }
    }
    // to get result
    public function get_student_details() {
        $student_id = $_SESSION['user_id'];
        $this->db->select("student_basic_details.*,student_profile.*,student_parent_details.*");
        $this->db->from("student_basic_details");
        $this->db->join("student_profile", "student_basic_details.student_id = student_profile.student_id");
        $this->db->join("student_parent_details", "student_basic_details.student_id = student_parent_details.student_id");
        $this->db->where('student_basic_details.student_id', $student_id);
        $query = $this->db->get();
        return $query->row();
    }
    // to get result
    public function getAllresultByID() {
        $student_id = $_SESSION['user_id'];
        $query = $this->db->get_where('result_academic', array('studentid' => $student_id));
        $result = $query->result_array();
        if ($query->num_rows() > 0) {
            return $result;
        } else {
            return 0;
        }
    }
    // to get result
    public function get_current_acadmic_attendance() {
        $student_id = $_SESSION['user_id'];
        $year_from = date("Y", strtotime($this->session->userdata('sch_start_date')));
        $year_upto = date("Y", strtotime($this->session->userdata('sch_end_date')));
        $this->db->select('attendance_id');
        $this->db->from('student_attendance');
        $this->db->where("(YEAR(attendance_date)='$year_from' OR YEAR(attendance_date) ='$year_upto')");
        $this->db->like('present_student_id', "$student_id");
        $present_days = $this->db->get()->num_rows();
        $this->db->select('attendance_id');
        $this->db->from('student_attendance');
        $this->db->where("(YEAR(attendance_date)='$year_from' OR YEAR(attendance_date) ='$year_upto')");
        $working_days = $this->db->get()->num_rows();
        $data = array('present_day' => $present_days, 'working_day' => $working_days,);
        return $data;
    }
    // to get result
    public function get_student_address() {
        $student_id = $_SESSION['user_id'];
        $query = $this->db->get_where('student_address', array('student_id' => $student_id));
        return $query->row_array();
    }
    // to get result
    public function get_student_parent_details() {
        $student_id = $_SESSION['user_id'];
        $query = $this->db->get_where('student_parent_details', array('student_id' => $student_id));
        return $query->row_array();
    }
    public function get_my_feedback($student_id) {
        $query = $this->db->get_where('feedback', array('student_id' => $student_id));
        return $query->result_array();
    }
    public function get_assignement($student_id) {
        $data = $this->get_class_section($student_id);
        $class = $data->st_class;
        $section = $data->section;
		$this->db->order_by('id','DESC');
        $query = $this->db->get_where('assignment', array('assignment_class' => $class, 'section' => $section));
        return $query->result_array();
    }
    public function get_homework($student_id) {
        $data = $this->get_class_section($student_id);
        $class = $data->st_class;
        $section = $data->section;
		$this->db->order_by('id','DESC');
        $query = $this->db->get_where('homework', array('homework_class' => $class, 'section' => $section));
        
		return $query->result_array();
    }
   
   
    public function view_event_detail($event_id) {
         
         $query = $this->db->get_where('event_management', array('event_id' => $event_id));
        return  $query->row();
    }
    public function enroll_for_event($event_id,$student_id) {
		
        $participant_id = $student_id;
        $participants_person = "parents";
        $fees_status = 'na';
        $query = $this->db->get_where('event_participant', array('event_id' => $event_id, 'participant_id' => $participant_id, 'participants_person' => $participants_person));
        $count = $query->num_rows();
        if ($count == 0) {
            $data = array('event_id' => $event_id, 'participant_id' => $participant_id, 'participants_person' => $participants_person, 'fees_status' => $fees_status);
            $this->db->insert('event_participant', $data);
            return "first";
        } else {
            return "already";
        }
    }
    public function get_daily_log($student_id) {
        $data = $this->get_class_section($student_id);
        $class = $data->st_class;
        $section = $data->section;
        $this->db->order_by('log_date', 'DESC');
        $query = $this->db->get_where('daily_log', array('log_class' => $class, 'log_section' => $section));
        return $query->result_array();
    }
    public function get_student_data($studentid) {
        $basicdetails = $this->get_basic_details($studentid);
        $address = $this->get_address($studentid);
        //$profile = $this->get_profile($studentid);
        //$parentsdetail = $this->get_parents_detail($studentid);
        //$previouinstitute = $this->get_previous_institute($studentid);
        //$medicaldetails = $this->get_medical_details($studentid);
        return array_merge($basicdetails, $address);
		//return $address;
						//'basicdetails'=> $basicdetails,
						//'address' => $address
					
    }
    public function get_basic_details($studentid) {
        $query = $this->db->get_where('student_basic_details', array('student_id' => $studentid));
        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return array();
        }
    }
    public function get_address($studentid) {
        $query = $this->db->get_where('student_address', array('student_id' => $studentid));
        if ($query->num_rows() > 0) {
            $std_data  = $query->row_array();
				$local_address =	$std_data['l_house_no'].' '.
									$std_data['l_street'].' '.
									$std_data['l_area'].' '.
									$std_data['l_city'].' '.
									$std_data['l_tahshil'].' '.
									$std_data['l_district'].' '.
									$std_data['l_state'].' '.
									$std_data['l_country'].'-'.
									$std_data['l_zip'];
               $permanent_address = $std_data['p_house_no'].' '.
									$std_data['p_street'].' '.
									$std_data['p_area'].' '.
									$std_data['p_city'].' '.
									$std_data['p_tahshil'].' '.
									$std_data['p_district'].' '.
									$std_data['p_state'].' '.
									$std_data['p_country'].'-'.
									$std_data['p_zip'];
			return array(
							'local_address' => $local_address,
							'permanent_address' => $permanent_address
						);
        } else {
            return array();
        }
    }
    public function get_profile($studentid) {
        $query = $this->db->get_where('student_profile', array('student_id' => $studentid));
        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return array();
        }
    }
    public function get_parents_detail($studentid) {
        $query = $this->db->get_where('student_parent_details', array('student_id' => $studentid));
        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return array();
        }
    }
    public function get_previous_institute($studentid) {
        $query = $this->db->get_where('student_previous_institute', array('student_id' => $studentid));
        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return array();
        }
    }
    public function get_medical_details($studentid) {
        $query = $this->db->get_where('student_medical_details', array('student_id' => $studentid));
        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return array();
        }
    }
    public function get_sibling_count($middle_name, $last_name) {
        $this->db->select('student_basic_details.first_name,student_basic_details.middle_name,student_basic_details.last_name,student_basic_details.student_id,users.role,users.status');
        $this->db->from('student_basic_details');
        $this->db->join('users', 'users.user_id=student_basic_details.student_id', 'left');
        $this->db->where('student_basic_details.middle_name', $middle_name);
        $this->db->where('student_basic_details.last_name', $last_name);
        $this->db->where('users.role', 'parents');
        $this->db->where('users.status', 'active');
        $this->db->order_by('student_basic_details.student_id', 'DESC');
        $query = $this->db->get();
        return $query->num_rows();
    }
    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    public function get_report_card_examwise($student_id, $exam_name)
    {
        $data =$this->db->get_where('result_academic',['studentid'=>$student_id,'exam_name'=>$exam_name]);
        return $data->result_array();
    }
    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
}
?>