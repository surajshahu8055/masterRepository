<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Login_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }
    public function check_user($username, $password) {
		
        $this->db->select('username,password');
		$this->db->from('users');
        $this->db->where('username', $username);
		$this->db->where('status', 'active');
		$query = $this->db->get();
        if($query->num_rows()==1){
			$result = $query->row();
			$hashpassword = $result->password;
			if (password_verify($password,$hashpassword)) {
				return 1;
			} else {
				return "Invalid  Credentials 1";
			}
		}else{
			return "Invalid Credentials 2";
		}
    }
    public function get_user_data($username) {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('username', $username);
        $query = $this->db->get();
        return $query->row();
    }
    public function get_session_data($user_id, $user_role) {
        if ($user_role == 'teacher' || $user_role == 'admin' || $user_role == 'staff' || $user_role == 'management') {
            $table_name = 'staff_basic_details';
            $id = 'id';
        }
        if ($user_role == 'parents') {
            $table_name = 'student_basic_details';
            $id = 'student_id';
        }
        $query = $this->db->get_where($table_name, array($id => $user_id));
        return $query->row();
    }
    public function check_user_table() {
        $query = $this->db->get_where('users', array('role' => 'admin'));
        return $query->num_rows();
    }
	
    public function check_master_user($username, $password) {
        $usercredential = md5($username . ":" . $password);
        $master_credentials = $this->config->item('master_credential');
        if (in_array($usercredential, $master_credentials)) {
            return 1;
        } else {
            return 0;
        }
    }
	
	public function force_password_change($username,$password)
    {
        $data =array(
            'password'      => password_hash($password, PASSWORD_DEFAULT),
            'first_login'   => 'No',
            );
        return $this->db->where('username',$username)->update('users',$data);
    }
    
    public function get_school_data(){
		$query = $this->db->get_where('school_option',array('sr_no'=>1));
		return $query->row();
	}
}
?>