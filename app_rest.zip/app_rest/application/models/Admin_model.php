<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Admin_model extends MY_Model {
    public function __construct() {
        parent::__construct();
    }
    public function view_subject() {
        $class_list = $_SESSION['class_list'];
        $query = $this->db->get('class_wise_subjects')->result_array();
        if(!empty($query)){
            $new_data['status'] = "SUCCESS";
            $new_data['message'] = "Subject list sent successfully";
            foreach ($query as $key) {
                $type = explode("_",$this->differenciate_subject($key['subject_id']));
                $data[] = array('id' => $key['id'], 'class' => $key['class'],'marks'=>$type[0],'grade'=>$type[1], 'total_subject' => count(explode(',', $key['subject_id'])),);
                $marks = 0;
                $grade = 0;
            }
            foreach ($class_list as $key_1) {
                foreach ($data as $key) {
                    if(!empty($key['class']) && $key['class'] == $key_1){
                        $new_data['response'][] = $key;
                    }
                }
            }
        }else{
            $new_data['status'] = "FAILED";
            $new_data['message'] = "No Subject Found";
            $new_data['response'] = null;
        }
        return $new_data;
    }
    public function differenciate_subject($subjects) {
        $temp = '';
        $data = '';
        $marks = 0;
        $grade = 0;
        $sub = explode(',', $subjects);
        foreach ($sub as $key) {
            $temp = $this->db->select('*')->from('subjects')->where('id', $key)->get()->row_array();
            if ($temp['type'] == 'Marks') {
                $marks+= 1;
            } else {
                $grade+= 1;
            }
        }
        $data = $marks."_".$grade;
        return $data;
    }
}
?>