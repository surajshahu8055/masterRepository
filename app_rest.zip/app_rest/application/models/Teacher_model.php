<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Teacher_model extends MY_Model {
    public function __construct() {
        parent::__construct();
    }
    public function check_login() {
        $login = $_SESSION['logged_in'];
        $role = $_SESSION['user_role'];
        if ($login == TRUE && $role == 'teacher') {
            return 1;
        } else {
            return 0;
        }
    }
    public function get_student_names($class_details) {
		$message = "Students not available";			
		if(count($class_details)==0){
			return array('response'=>$message);
		}else{
			$class = $class_details->class_assigned;
			$section = $class_details->section_assigned;
			$this->db->select('student_id,first_name,middle_name,last_name');
			$query = $this->db->get_where('student_basic_details', array('st_class' => $class, 'section' => $section));
			return $query->result_array();
		}
    }
    public function get_class_details($teacher_id) {
        $query = $this->db->get_where('teacher_class', array('teacher_id' => $teacher_id));
        return $query->row();
    }
    
    //####################################################################
    // Dynamic subject, class and section by vishal
    //####################################################################
    
    public function get_assigned_classes($teacher_id) {
        // Fetch classes that assign to teacher
        $this->db->select('class');
        $this->db->from('subject_teacher');
        $where = array('academic_year' =>  $_SESSION['academic_year'], 'staff_id' => $teacher_id);
        $this->db->where($where);
        $this->db->group_by('class');
        $query = $this->db->get();
        return $query->result_array();
    }
    
    public function get_assigned_class_section($teacher_id, $class_name) {
        // Fetch classes that assign to teacher
        $this->db->select('section');
        $this->db->from('subject_teacher');
        $where = array('academic_year' =>  $_SESSION['academic_year'], 'staff_id' => $teacher_id, 'class' => $class_name);
        $this->db->where($where);
        $this->db->group_by('section');
        $query = $this->db->get();
        return $query->result_array();
    }
    
    public function get_assigned_subjects($teacher_id, $class_name, $section) {
        // Fetch classes that assign to teacher
        $this->db->select('subject');
        $this->db->from('subject_teacher');
        $where = array('academic_year' =>  $_SESSION['academic_year'], 'staff_id' => $teacher_id, 'class' => $class_name, 'section' => $section);
        $this->db->where($where);
        $this->db->group_by('subject');
        $query = $this->db->get();
        return $query->result_array();
    }
    
    //####################################################################
    // RESULT MODULE
    //####################################################################
    
    public function get_student_result_studentid($student_id,$class) {
        $query = $this->db->get_where('result_academic', array('studentid' => $student_id,'class'=>$class));
        $check_student = $query->num_rows();
        if ($check_student > 0) {
            return $query->result_array();
        } else {
            return 'false';
        }
    }
    public function get_student_grade_studentid($student_id,$class) {
        $query = $this->db->get_where('result_extra', array('studentid' => $student_id,'class'=>$class));
        $check_student = $query->num_rows();
        if ($check_student > 0) {
            return $query->result_array();
        } else {
            return 'false';
        }
    }
   
    public function mark_student_attendance() {
        $class = $this->input->post('attendance_class');
        $class_section = $this->input->post('class_section');
        $attendance_date = date('Y-m-d', strtotime($this->input->post('attendance_date')));
        if ($attendance_date > date("Y-m-d")) {
            $message = "Sorry! But you can't mark future attendance.<br>Date should be past or today's date.";
			return array('response'=>$message);
        } else {
            $query = $this->db->query("SELECT * FROM student_attendance WHERE stu_class = '$class' AND attendance_date = '$attendance_date' and class_section = '$class_section'");
            $result = $query->num_rows();
            if ($result > 0) {
                $message =  "Attendance for the class $class  section $class_section of the date $attendance_date is already done.";
				$message = "Already attendance had taken for given date.";
				return array('response'=>$message);
            } else {
                $attendance_array = $this->input->post('attendance[]');
                $present_student = implode(',', $attendance_array);
                $teacher_id = $this->input->post('teacher_id');
				
                $data = array('teacher_id' => $teacher_id, 'stu_class' => $class, 'class_section' => $class_section, 'attendance_date' => $attendance_date, 'present_student_id' => $present_student);
                $this->db->insert('student_attendance', $data);
				$message = "Attendance is completed";
				return array('response'=>$message);
            }
        }
    }
    public function add_marks($data_marks) {
        
		if($this->db->insert('result_academic', $data_marks))
		{
			return "Marks added!";
		}else{
			return "Marks not added!";
		}
		
    }
    public function add_grades($data_grade) {
        if($this->db->insert('result_extra', $data_grade))
		{
			return "Grade Added!";
		}else{
			return "Grade not added!";
		}
    }
	
    public function get_student_details($studentid) {
        $this->db->select("student_basic_details.*,student_profile.*,student_parent_details.*");
        $this->db->from("student_basic_details");
        $this->db->join("student_profile", "student_basic_details.student_id = student_profile.student_id");
        $this->db->join("student_parent_details", "student_basic_details.student_id = student_parent_details.student_id");
        $this->db->where('student_basic_details.student_id', $studentid);
        $query = $this->db->get();
        return $query->row();
    }
    public function add_feedback() {
        $data = array(
					'student_id' => $this->input->post('student_id'),
					'content' => $this->input->post('content'), 
					'teacher_id' => $this->input->post('teacher_id'),
					'date' => date('Y-m-d')
				);
        if($this->db->insert('feedback', $data)){
			$message = "Feedback submitted sucessfully!";
			return array('response'=>$message);
		}else{
			$message = "Some Error is occurred!";
			return array('response'=>$message);
		}
    }
    public function get_student_feedback($teacher_id) {
        $this->db->select("feedback.*,student_basic_details.first_name,student_basic_details.last_name");
        $this->db->from("feedback");
        $this->db->join("student_basic_details", "student_basic_details.student_id = feedback.student_id");
        $this->db->where('feedback.teacher_id', $teacher_id);
        $this->db->order_by('feedback.sr_no','DESC');
        $query = $this->db->get();
        return $query->result_array();
    }
    public function add_assignment() {
		/*
        if (!empty($_FILES['attachment']['name'])) {
			if(isset($_SERVER['HTTPS']))
			{ 
				$protocol = "https://";
		    }else{
				$protocol = "http://"; 
			}
			$server_name = $_SERVER['SERVER_NAME'];
			$folder_name = '/app/';
			$base_url = $protocol.$server_name.$folder_name;
			
            $file_to_upload = 'attachment';
            $filename = $this->input->post('title');
            $path = $base_url.'uploads/assignment_files/';
            $filetypes = '*';
            $filename = $this->upload_file($file_to_upload, $filename, $path, $filetypes);
        } else {
            $filename = 'FIle not uploaded!';
        }
		echo $filename;
		exit; 
		*/
		
        $data = array('teacher_id' => $this->input->post('teacher_id'), 
					  'assignment_class' => $this->input->post('assignment_class'), 
					  'section' => $this->input->post('section'), 
					  'given_date' => date('Y-m-d'), 
					  'submission_date' => date('Y-m-d', strtotime($this->input->post('submission_date'))), 
					  'subject' => $this->input->post('subject'), 
					  'title' => $this->input->post('title'), 
					  'description' => $this->input->post('description'),
					  'attachment' => ""
					  );
			
					  
		//return $this->db->insert('assignment', $data);
		
		if($this->db->insert('assignment', $data)){
			$message = "Assignment submitted sucessfully!";
			return array('response'=>$message);
		}else{
			$message = "Assignment not submitted due to some internal error!";
			return array('response'=>$message);
		}
    }
    public function get_assignement($teacher_id) {
        $this->db->order_by('id','DESC');
        $query = $this->db->get_where('assignment', array('teacher_id' => $teacher_id));
        return $query->result_array();
    }
    public function add_homework() {
        
        $data = array('teacher_id' => $this->input->post('teacher_id'),
					  'homework_class' => $this->input->post('assignment_class'),
					  'section' => $this->input->post('section'),
					  'given_date' => date('Y-m-d'),
					  'submission_date' => date('Y-m-d', strtotime($this->input->post('submission_date'))),
					  'subject' => $this->input->post('subject'),
					  'title' => $this->input->post('title'),
					  'description' => $this->input->post('description')
					  );
					  
        if($this->db->insert('homework', $data)){
			$message = "Homework submitted sucessfully!";
			return array('response'=>$message);
		}else{
			$message = "Homework not submitted due to some internal error!";
			return array('response'=>$message);
		}
    }
    public function get_homework($teacher_id) {
        $this->db->order_by('id','DESC');
        $query = $this->db->get_where('homework', array('teacher_id' => $teacher_id));
		return $query->result_array();
    }
    
    public function get_all_events() {
        $query = $this->db->get('event_management');
		if($query->num_rows()>0){
			return $query->result_array();
		}else{
			$message = "Data Not available!";
			return array('response'=>$message);
		}
    }
    public function get_event_detail($event_id) {
        $query = $this->db->get_where('event_management', array('event_id' => $event_id));
        return  $query->row();
    }
    public function enroll_for_event($teacher_id,$event_id) {
        $participant_id = $teacher_id;
        $participants_person = "teacher";
        $fees_status = 'na';
        $query = $this->db->get_where('event_participant', array('event_id' => $event_id, 'participant_id' => $participant_id));
        $count = $query->num_rows();
        if ($count == 0) {
            $data = array('event_id' => $event_id, 'participant_id' => $participant_id, 'participants_person' => $participants_person, 'fees_status' => $fees_status);
            $this->db->insert('event_participant', $data);
            return "first"; // Thanks for enrollment 
        } else {
            return "already"; // Already Enrolled
        }
    }
	
    public function view_class_time_table($class, $section, $day) {
        $data = Array();
        $this->db->select("$day,time");
        $this->db->from('class_time_table');
        $where = array('ttclass' =>$class, 'section'=> $section);
        $this->db->where($where);
        $query = $this->db->get()->result_array();
		foreach($query as $temp){
			$data[] = array(	
				'subject' => $temp[$day],
				'time' => $temp['time']
			);
		}
        return $data;
    }
	
	public function add_daily_log() {
        $data = array(
		'teacher_id' => $this->input->post('teacher_id'), 'log_date' => date('Y-m-d', strtotime($this->input->post('log_date'))), 'log_class' => $this->input->post('log_class'), 'log_section' => $this->input->post('log_section'), 'log_subject' => $this->input->post('log_subject'), 'log_description' => $this->input->post('log_description'));
        if ($this->db->insert('daily_log', $data)) {
          
			$message = "Log submitted successfully!";
			return array('response'=>$message);
        } else {
            $message = "Some error occurred !";
			return array('response'=>$message);
        }
    }
    public function get_daily_log($teacher_id) {
        $this->db->order_by('sr_no','DESC');
        $query = $this->db->get_where('daily_log', array('teacher_id' => $teacher_id));
		return $query->result_array() ;
    }
	/*START LEAVE MANAGER*/
	public function apply_for_leave($teacher_id) {
		//$date_expire = '2014-08-06 00:00:00';    
		$date_f = date('Y-m-d', strtotime($this->input->post('date_from')));
		$date_t = date('Y-m-d', strtotime($this->input->post('date_to')));
		$datefrom = new DateTime($date_f);
		$dateto = new DateTime($date_t);
		$days_diff = ($datefrom->diff($dateto)->format("%d"))+1;
        $data = array(
						'staff_id' => $teacher_id,
						'no_of_days' => $days_diff,
						'leave_type' => $this->input->post('leave_type'),
						'date_from' => $date_f,
						'date_to' => $date_t,
						'reason' => $this->input->post('reason'),
						'status' => 'Pending'
					);
		if($this->db->insert('leave_management', $data)){
		    $message = "Leave submitted successfully.";
			return array('response'=>$message);
	   }else{
		    $message = "Leave not submitted due to some internal error!";
			return array('response'=>$message);
	   }
    }
	
    public function get_my_leaves($teacher_id) {
        $this->db->order_by('srno','DESC');
        $query = $this->db->get_where('leave_management',array('staff_id'=>$teacher_id));
		if($query->num_rows()>0){
			return $query->result_array();
		}else{
			$message = "Data not available!";
			return array('response'=>$message);
		}
    }
	/*END LEAVE MANAGER*/

    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    public function get_students_attendance_by_date($class , $section , $attendance_date){
        $result = $this->db->get_where('student_attendance',['stu_class'=>$class,'class_section'=>$section,'attendance_date'=>$attendance_date]);
        $att = $result->result_array();
        // echo "<pre>";
        // print_r ($att);
        // echo "</pre>";
        return $att;
    }

    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


        // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    // for teacher
    public function get_student_attendance_daywise() {
       $class = $this->input->post('class');
       $section = $this->input->post('section');
       $date =  date('Y-m-d',strtotime($this->input->post('date')));             
       $search = array(
                    'st_class' => $class ,
                    'section'=>$section, 
                );
       $stud_list = $this->db->get_where('student_basic_details',$search)->result_array();
        $status = $this->db->query("SELECT `attendance_id` FROM `student_attendance` WHERE `stu_class` = '$class' AND `class_section` = '$section' AND `attendance_date` = '$date' ")->num_rows();
        if($status==0){
            return array();
        }
       foreach ($stud_list as $stud) {
            $sid = $stud['student_id'];
            $attendance_id = $this->db->query("SELECT `attendance_id` FROM `student_attendance` WHERE `stu_class` = '$class' AND `class_section` = '$section' AND `attendance_date` = '$date' AND `present_student_id` LIKE '%$sid%' ORDER BY attendance_id ASC")->row();
            
            $atten =  ($attendance_id =="")?'A':'P';
            $data[] =  array(
                            'student_id'=> $stud['student_id'],
                            'student_name'=> $stud['first_name'].' '.$stud['middle_name'].' '.$stud['last_name'],
                            'att' => $atten,
                        );
        }
        return $data;
    }
    public function get_student_attendance() {
        $class = $this->input->post('class');
        $section = $this->input->post('section');
        $attendance_date = date('Y-m-d',strtotime($this->input->post('date')));
        $query = $this->db->get_where('student_attendance',
         ['stu_class' => $class, 'class_section' => $section, 'attendance_date' => $attendance_date]);
        return $query->row();
    }
	
    public function get_student_attendance_by_month() {
       $class = $this->input->post('class');
       $section = $this->input->post('section');
       $mon = date('m',strtotime($this->input->post('month')));
       $year = date('Y',strtotime($this->input->post('month')));
       $academic_year = $_SESSION['academic_year']; //date('Y').'-'.date('Y',strtotime('+1year'));
       $search = array(
                    'st_class' => $class ,
                    'section'=>$section,
                    'academic_year'=> $academic_year 
                );
       $stud_list = $this->db->get_where('student_basic_details',$search)->result_array();
      
       $data = array();
       foreach ($stud_list as $stud) {
            $sid = $stud['student_id'];
            $data[] =  array(
                            'student_id'=> $stud['student_id'],
							'name'=> $stud['first_name'].' '.$stud['middle_name'].' '.$stud['last_name'],
                            'att' => $this->db->query("SELECT COUNT(`attendance_id`) AS present_day FROM `student_attendance` WHERE `stu_class` = '$class' AND `class_section` = '$section' AND MONTH(`attendance_date`) = '$mon' AND YEAR(`attendance_date`)='$year' AND `present_student_id` LIKE '%$sid%'")->row()->present_day,
                            'wd'  => $this->db->query("SELECT COUNT(`attendance_id`) AS days FROM `student_attendance` WHERE `stu_class` = '$class' AND `class_section` = '$section' AND MONTH(`attendance_date`) = '$mon' AND YEAR(`attendance_date`)='$year'")->row()->days,
                        );
        }
        return  $data;
    }

    public function get_attendace_record_student(){
        $attendance=array();
		$student_id = $this->input->post('student_id');
           $class = $this->input->post('class');
           $section = $this->input->post('section');
        $present_day = $this->db->query("SELECT YEAR(`attendance_date`) AS y, MONTH(`attendance_date`) AS m, COUNT(DISTINCT `attendance_id`) AS days FROM `student_attendance` WHERE `present_student_id` LIKE '%$student_id%' GROUP BY y, m ORDER BY y,m DESC LIMIT 12")->result_array();
        $working_day = $this->db->query("SELECT YEAR(`attendance_date`) AS y, MONTH(`attendance_date`) AS m, COUNT(DISTINCT `attendance_id`) AS days FROM `student_attendance` WHERE `stu_class` = '$class' AND `class_section` = '$section' GROUP BY y, m ORDER BY y,m DESC LIMIT 12")->result_array();
        $j=0;

        if(empty($present_day)){
                for ($i=0; $i < count($working_day) ; $i++) { 
                    $date_is= "2018-".$working_day[$i]['m']."-03";
                    $attendance[] = array(
                                    'year'       => $working_day[$i]['y'],
                                    'month'        => date("M",strtotime($date_is)),
                                    'present_day' => 0,
                                    'working_day' => $working_day[$i]['days'],
                                );
                }
        }else{
            for ($i=0; $i < count($working_day) ; $i++) { 

                if($working_day[$i]['y'] == $present_day[$j]['y'] && 
                   $working_day[$i]['m'] == $present_day[$j]['m']){
                        $pre_days = $present_day[$j]['days'];
                    // $j++;
                    (count($working_day) == count($present_day))? $j++ : $j;
                }else{
                        $pre_days = 0;
                }
                $date_is= "2018-".$working_day[$i]['m']."-03";
                $attendance[] = array(
                                'year'       => $working_day[$i]['y'],
                                'month'        => date("M",strtotime($date_is)),
                                'present_day' => $pre_days,
                                'working_day' => $working_day[$i]['days'],
                            );
            }
        }

        return $attendance;
    }

    //=========================== teacher profile ====================================//
    public function get_teacher_details($data)
    {
        return $this->db->get_where('staff_basic_details',$data)->row_array();
    }

    public function get_teacher_address($data)
    {
        return $this->db->get_where('staff_address',$data)->row_array();
    }

    public function get_teacher_education($data)
    {
        return $this->db->get_where('staff_education',$data)->result_array();
    }

    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    public function get_class_teacher_details($teacher_id) {
        $query = $this->db->get_where('teacher_class', array('teacher_id' => $teacher_id));
        $result =  $query->row();
        
        $data = array(
                'response'      => ($result!="")?true:false,
                'class_assigned'=> @$result->class_assigned,
                'section_assigned'=> @$result->section_assigned,
                );
        return $data;
    }

    public function get_class_teacher_subject($id)
    {
        $this->db->query("SELECT c.`class_assigned`,c.`section_assigned`,t.`staff_id`,t.`class`,t.`section`,t.`subject` FROM `teacher_class` c LEFT JOIN `subject_teacher` t WHERE t.`staff_id` = '$id'");
    }

    public function get_subject_teacher($id){
        $this->db->select('subject_teacher.staff_id,subject_teacher.class,subject_teacher.section,subject_teacher.subject,staff_basic_details.first_name,staff_basic_details.last_name');
        $this->db->from('subject_teacher');
        $this->db->join('staff_basic_details','staff_basic_details.id = subject_teacher.staff_id');
        $this->db->where('subject_teacher.staff_id',$id);
        $query = $this->db->get();       
        return  $query->result_array();
    }
    // get_todays_leactures
    public function get_todays_leactures_get($teacher_id){
        $day = strtolower(date('l'));
        $classes = $this->db->get_where('subject_teacher',['staff_id' => $teacher_id])->result_array();
        foreach ($classes as $class) {            
            $class_data[] = array(
                            'ttclass' => $class['class'],                            
                            'section' => $class['section'],
                            $day      => $class['subject'],
                            );  
        }
        $tt_count = $this->db->get('class_time_table')->num_rows();

        if(!empty($class_data)){
            for ($j=0; $j < count($class_data) ; $j++) {                 
                    $this->db->select("ttclass,section,time,$day AS subject");
                    $this->db->from("class_time_table");            
                    $this->db->order_by("time","ASC");            
                    $this->db->where($class_data[$j]);
                    $temp = $this->db->get()->result_array();
                    foreach ($temp as $t) {
                        $lectures[] =$t;    // unsorted lectures 
                    }
                }
            if(!empty($lectures)) {
                for($i=0; $i<count($lectures)-1; $i++) {
                    $min = $i;
                    for($j=$i+1; $j<count($lectures); $j++) {
                        if ($lectures[$j]['time'] < $lectures[$min]['time']) {
                            $min = $j;
                        }
                    }
                    $temp_array = $lectures[$min];
                    $lectures[$min] = $lectures[$i];
                    $lectures[$i] = $temp_array ;
                }
                return $lectures;   // sorted lectures by time


            }else{
                return array();
            }
        }else{
            return array();
        }
    }
}
?>