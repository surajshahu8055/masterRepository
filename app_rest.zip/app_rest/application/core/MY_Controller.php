<?php if (!defined('BASEPATH'))exit('No direct script access allowed');
require(APPPATH.'/libraries/REST_Controller.php');
class MY_Controller extends  REST_Controller {
	
    public function __construct() {
        parent::__construct();
        $this->load->model('MY_Model','my_model');
		$_SESSION['class_list']  =  array('Nursery','KG1', 'KG2', '1st', '2nd','3rd', '4th', '5th', '6th', '7th', '8th', '9th','10th', '11th', '12th');
		
		$stu_query = $this->db->query('SELECT student_id FROM student_basic_details');
        if ($stu_query->num_rows() == 0) {
           $this->db->query('ALTER TABLE student_basic_details AUTO_INCREMENT=10001');
        }
		$staff_query = $this->db->query('SELECT id FROM staff_basic_details');
        if ($staff_query->num_rows() == 0) {
            $this->db->query('ALTER TABLE staff_basic_details AUTO_INCREMENT=10001');
        } 
		
		$sch_data = $this->my_model->get_school_data();
		
		$school_data = array(
							'sch_name' => $sch_data->school_name, 
							'sch_country' => $sch_data->country,
							'sch_address' => $sch_data->address,
							'sch_email' => $sch_data->email,
							'sch_phone' =>$sch_data->phone,
							'sch_mobile' =>$sch_data->mobile,
							'sch_fax' =>$sch_data->fax,
							'sch_contact_person' =>$sch_data->contact_person,
							'sch_start_date' =>$sch_data->session_start_date,
							'sch_end_date' =>$sch_data->session_end_date,
							'sch_code' =>$sch_data->school_code,
							'academic_year' => date('Y',strtotime($sch_data->session_start_date))."-".date('Y',strtotime($sch_data->session_end_date)),
						);
        $this->session->set_userdata($school_data);
		$country = $this->my_model->get_country_name();
		$_SESSION['country'] =  $country;
	}
	
	public function news_get() {
		$data = $this->my_model->get_publish_news();
		$this->response($data);
    }
	public function circulars_get() {
        $data = $this->my_model->get_publish_circulars();
		$this->response($data);
    }
	
	public function read_circulars_get() {
        $sr_no = $this->uri->segment('3');
        $data = $this->staff_model->get_single_circulars($sr_no);
        $this->response($data);
    }
    public function read_news_get() {
        $sr_no = $this->uri->segment('3');
        $data['news'] = $this->staff_model->get_single_news($sr_no);
        $this->response($data);
    }
	
	//Communication Portal
	public function messages(){	
		if($_SESSION['user_role'] =='teacher'){
			$data['controller'] = 'teacher';
			$data['controller_name'] = 'Teacher';
		}else{
			$data['controller'] = 'parents';
			$data['controller_name'] = 'Parents';
		}
		$data['send_to'] =  $this->my_model->get_send_to();
		$this->load->view("isyncerp/template/messages",$data);
	}
	public function get_messangers_list(){	 
		$data = $this->my_model->get_messangers_list();
		echo json_encode($data);
	}
	public function get_sent_message_list(){	 
		$data = $this->my_model->get_sent_message_list();
		echo json_encode($data);
	}
	public function get_unread_message_count(){	 
		$data = $this->my_model->get_unread_message_count();
		echo json_encode($data);
	}
	public function get_single_message(){	
		$messageid = $this->uri->segment('3');
		$data = $this->my_model->get_single_message($messageid);
		echo json_encode($data);
	}
	public function reply_to(){	
		$message_data = json_decode(file_get_contents("php://input"));
		$data = $this->my_model->reply_to($message_data);
		echo json_encode($data);
	}
	public function send_new_message(){	
		$message_data = json_decode(file_get_contents("php://input"));
		$to  = $message_data->message_to;
	
		 
		if (in_array("all", $to) and count($to)>1)
		{
			$data =  "Hey You can't select 'Send To All' with other students!";
		}
		elseif(!in_array("all", $to) and count($to)>1){
			
			$data = $this->my_model->send_new_message($message_data);
			
		}elseif(in_array("all", $to) and count($to)==1){
			
			$data = $this->my_model->send_new_message_to_all($message_data);
		}
		
		echo json_encode($data);
	}
	
	
	public function school_setting()
	{
		if($_SESSION['logged_in'] !== TRUE && ($_SESSION['user_role']!=='master' || $_SESSION['user_role']!=='admin')){
				$this->session->set_flashdata('invalid_credentials', 'Please login to access the master admin area!');
				redirect('master_admin');
		}else{
				if($_SESSION['user_role'] =='master'){
					$data['controller'] = 'master_admin';
					$data['controller_name'] = 'Master Admin';
				}else{
					$data['controller'] = 'admin';
					$data['controller_name'] = 'Admin';
				}
				$data['view'] = 'School Settings';
				$data['page_name'] = 'template/school_settings';
				$this->load->view("isyncerp/template/dashboard",$data);
		}
	}
	
	public function add_school_settings()
	{
		if($_SESSION['logged_in'] !== TRUE && ($_SESSION['user_role']!=='master' || $_SESSION['user_role']!=='admin')){
				$this->session->set_flashdata('invalid_credentials', 'Please login to access the master admin area!');
				redirect('master_admin');
		}else{
				$result  = $this->my_model->add_school_settings();
				$this->session->set_flashdata('sucess_message', $result);
				if($_SESSION['user_role']=='master'){
					redirect('master_admin/school_setting');
				}else{
					redirect('admin/school_setting');
				}
		}
	}
	
	public function add_account_settings()
	{
		if($_SESSION['logged_in'] !== TRUE && ($_SESSION['user_role']!=='master' || $_SESSION['user_role']!=='admin')){
				$this->session->set_flashdata('invalid_credentials', 'Please login to access the master admin area!');
				redirect('master_admin');
		}else{
				$result  = $this->my_model->add_account_settings();
				$this->session->set_flashdata('sucess_message', $result);
				if($_SESSION['user_role']=='master'){
					redirect('master_admin/school_setting');
				}else{
					redirect('admin/school_setting');
				}
		}
	}
	
	public function view_school_settings(){
		
		if($_SESSION['logged_in'] !== TRUE && ($_SESSION['user_role']!=='master' || $_SESSION['user_role']!=='admin')){
				$this->session->set_flashdata('invalid_credentials', 'Please login to access the master admin area!');
				redirect('master_admin');
		}else{
				$data['school_data']= $this->my_model->get_school_settings();
				if($_SESSION['user_role'] =='master'){
					$data['controller'] = 'master_admin';
					$data['controller_name'] = 'Master Admin';
				}else{
					$data['controller'] = 'admin';
					$data['controller_name'] = 'Admin';
				}
				$data['view'] = 'View School Settings';
				$data['page_name'] = 'template/view_school_settings';
				$this->load->view("isyncerp/template/dashboard",$data);
		}
	}
	public function update_school_settings()
	{
		if($_SESSION['logged_in'] !== TRUE && ($_SESSION['user_role']!=='master' || $_SESSION['user_role']!=='admin')){
				$this->session->set_flashdata('invalid_credentials', 'Please login to access the master admin area!');
				redirect('master_admin');
		}else{
				$old_data = $_SESSION['temp_school_setting'];
				$new_data = array(
								'school_name' 		=> $this->input->post('school_name'),
								'address'			=> $this->input->post('address'),
								'email'				=> $this->input->post('email'),
								'phone'				=> $this->input->post('phone'),
								'mobile'			=> $this->input->post('mobile'),
								'fax'				=> $this->input->post('fax'),
								'contact_person'	=> $this->input->post('contact_person'),
								'session_start_date'=> $this->input->post('session_start_date'),
								'session_end_date'	=> $this->input->post('session_end_date'),
								'school_code'		=> $this->input->post('school_code'),
								'country'			=> $this->input->post('country'),
								
							);	
				$data = array_diff($new_data,$old_data);
				$result  = $this->my_model->update_school_settings($data);
				$this->session->set_flashdata('success_message', $result);
				if($_SESSION['user_role']=='master'){
					redirect('master_admin/view_school_settings');
				}else{
					redirect('admin/view_school_settings');
				}
		}
	}
	
	//IMPORT STUDENT TEMPLATE
    public function student_basic_details_template() {
        $this->my_model->student_basic_details_template();
    }
    public function student_address_template() {
        $this->my_model->student_address_template();
    }
    public function student_parent_template() {
        $this->my_model->student_parent_template();
    }
    public function student_previous_school_details() {
        $this->my_model->student_previous_school_details();
    }
    public function student_medical_template() {
        $this->my_model->student_medical_template();
    }
    public function student_profile_template() {
        $this->my_model->student_profile_template();
    }
    public function student_usernames_template() {
        $this->my_model->student_usernames_template();
    }
	
	//UPLOAD STUDENT DATA
    public function upload_student_basic_details() {
        $input_name = 'stundent_basic_details';
        $column_values = $this->get_column_values($input_name);
        $result = $this->my_model->upload_student_basic_details($column_values);
        $this->session->set_flashdata('success_message', $result);
		if($_SESSION['user_role'] =='admin'){
			redirect('admin/import_student_data');
		}elseif($_SESSION['user_role'] == 'staff'){
			redirect('staff/import_student_data');
		}
    }
    public function upload_student_address() {
        $input_name = 'student_address';
        $column_values = $this->get_column_values($input_name);
        $result = $this->my_model->upload_student_address($column_values);
        $this->session->set_flashdata('success_message', $result);
		if($_SESSION['user_role'] =='admin'){
			redirect('admin/import_student_data');
		}elseif($_SESSION['user_role'] == 'staff'){
			redirect('staff/import_student_data');
		}
    }
    public function upload_student_parent_details() {
        $input_name = 'student_parent_details';
        $column_values = $this->get_column_values($input_name);
        $result = $this->my_model->upload_student_parent_details($column_values);
        $this->session->set_flashdata('success_message', $result);
        if($_SESSION['user_role'] =='admin'){
			redirect('admin/import_student_data');
		}elseif($_SESSION['user_role'] == 'staff'){
			redirect('staff/import_student_data');
		}
    }
    public function upload_previous_school_details() {
        $input_name = 'previous_school_details';
        $column_values = $this->get_column_values($input_name);
        $result = $this->my_model->upload_previous_school_details($column_values);
        $this->session->set_flashdata('success_message', $result);
		if($_SESSION['user_role'] =='admin'){
			redirect('admin/import_student_data');
		}elseif($_SESSION['user_role'] == 'staff'){
			redirect('staff/import_student_data');
		}
    }
    public function upload_student_medical_details() {
        $input_name = 'student_medical_details';
        $column_values = $this->get_column_values($input_name);
        $result = $this->my_model->upload_student_medical_details($column_values);
        $this->session->set_flashdata('success_message', $result);
        if($_SESSION['user_role'] =='admin'){
			redirect('admin/import_student_data');
		}elseif($_SESSION['user_role'] == 'staff'){
			redirect('staff/import_student_data');
		}
    }
    public function upload_student_profile_details() {
        $input_name = 'student_profile_details';
        $column_values = $this->get_column_values($input_name);
        $result = $this->my_model->upload_student_profile_details($column_values);
        $this->session->set_flashdata('success_message', $result);
        if($_SESSION['user_role'] =='admin'){
			redirect('admin/import_student_data');
		}elseif($_SESSION['user_role'] == 'staff'){
			redirect('staff/import_student_data');
		}
    }
    public function upload_student_usernames() {
        $input_name = 'student_usernames';
        $column_values = $this->get_column_values($input_name);
        $result = $this->my_model->upload_student_usernames($column_values);
        $this->session->set_flashdata('success_message', $result);
		if($_SESSION['user_role'] =='admin'){
			redirect('admin/import_student_data');
		}elseif($_SESSION['user_role'] == 'staff'){
			redirect('staff/import_student_data');
		}
    }
	//UPLOAD STUDENT DATA
	
	
	public function get_column_values($input_name){
		
		$filename = $_FILES[$input_name]["tmp_name"];
        $ext = strchr($_FILES[$input_name]["name"], '.');
        $column_values = '';
        $i = 0;
        if ($ext == '.csv') {
            if ($_FILES[$input_name]["size"] > 0) {
                $file = fopen($filename, "r");
                while (($data = fgetcsv($file, 100000, ",")) !== FALSE) {
                    $num = count($data);
                    if ($i > 0) {
                        for ($j = 0; $j < $num; $j++) {
                            $column_values = $column_values . "'" . $data[$j] . "'" . ", ";
                        }
						$column_values = substr(trim($column_values), 0, -1);
						$column_values = $column_values.';';
                    }
                    $i++;
                }
				$column_array = explode(';',$column_values);
				
				for($i=0;$i<count($column_array);$i++){
					$temp[] = '('.$column_array[$i].')';
				}
				$column_values  = substr(trim(implode(',',$temp)), 0, -3);
                fclose($file);
			}
        }
		return $column_values;
		
	}
	

	public function change_password(){
		$result = $this->my_model->change_password();
		echo $result;
	}
	// get_attendace_record_month_post
	public function get_attendace_record_month_post() {
        $data = $this->my_model->get_attendace_record_month();
        if(!empty($data)){
    		foreach ($data as $key => $value) {
    			if($value['att']=='Absent'){
    				$temp[] = array(
		            	'attendance_id' => $value['data']['attendance_id'],
		            	'stu_class' => $value['data']['stu_class'],
		            	'class_section'=> $value['data']['class_section'],
		            	'attendance_date'=> $value['data']['attendance_date'],
		            	'present_student_id'=> $value['data']['present_student_id'],
		            	'teacher_id'=> $value['data']['teacher_id'],
		            	'att'=>$value['att']

		            	);
    			}else{
    				$result = array();
	            }
    		}
    		if(!empty($temp)){
    			for ($i = 0;$i < count($temp);$i++) {
		            if($temp[$i]['att']=='Absent'){
		            	 $result[] = array(
		            		'date' => date('d M,Y', strtotime($temp[$i]['attendance_date'])),
		            		'attendance_status' => $temp[$i]['att'],
		            	);
		            }else{
		            	$result = array();
		            }
		        }
		        $this->response($result);
    		}else{
    			$this->response(array());
    		}
        }else{
        	$this->response(array());
        }
    }
	
	// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%//
}

?>