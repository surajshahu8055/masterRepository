<?php
class MY_Model extends CI_Model {

    public function __construct() {
        parent::__construct();
		$this->load->dbutil();
        $this->load->helper('file');
        $this->load->helper('download');
    }

	public function upload_file($file_to_upload,$filename,$path,$filetypes) {
		
		$ext = pathinfo($_FILES[$file_to_upload]['name'], PATHINFO_EXTENSION);
		$config['file_name'] = $filename.'_'.mt_rand(1000, 1000000).'.'.$ext;
		$config['upload_path'] = './uploads/assignment_files/';
        $config['allowed_types'] = $filetypes;
		$config['file_ext_tolower'] = TRUE;
		$this->load->library('upload', $config);
		
		if($this->upload->do_upload($file_to_upload)){
			
		}else{
			$error = array('error' => $this->upload->display_errors());
			print_r($error);
			exit;
		}	
	}
	
	public function send_email($email_to, $body,$subject,$from) {
			
        $config = array(
            'protocol' => 'ssmtp',
            'smtp_host' => 'ssl://mail.eastpointschool.in',
            'smtp_port' => '465',
            'smtp_timeout' => '7',
            'smtp_user' => 'admin@eastpointschool.in',
            'smtp_pass' => 'Eastpointschool@2018',
            'charset' => 'utf-8',
            'mailtype' => 'text/plain',
            'validation' => TRUE,
            'crlf' => '\r\n',
            'newline' => '\r\n',
        );
        $this->load->library('email', $config);
        $this->email->from('admin@eastpointschool.in', $from);
        $this->email->subject($subject);
        $this->email->to($email_to);
        $this->email->message($body);
        $this->email->send();
    }
	
	//GET ID
	public function get_staff_id() {
		$count = $this->db->query('SELECT id FROM staff_basic_details');
		if ($count->num_rows() > 0) {
			$query = $this->db->query('SELECT MAX(id) AS id FROM staff_basic_details');
        
            $result = $query->row();
            return $result->id + 1;
        } else {
            return '10001';
        }
    }
	public function get_student_id() {
        $count = $this->db->query('SELECT student_id FROM student_basic_details');
        if ($count->num_rows() > 0) {
			$query = $this->db->query('SELECT MAX(student_id) AS student_id FROM student_basic_details');
            $result = $query->row();
            return $result->student_id + 1;
        } else {
            return '10001';
        }
    }
	public function get_staff_list() {
		
        $this->db->select('staff_basic_details.*,users.username,users.password,users.role,users.status');
        $this->db->from('staff_basic_details');
        $this->db->join('users', 'staff_basic_details.id = users.user_id', "LEFT");
		$this->db->where('users.status','active');
		$this->db->where('users.role!=','parents');
        $query = $this->db->get();
        return $query->result_array();
    }
	
	public function get_student_list() {
        $this->db->select('student_basic_details.*,users.username,users.password,users.status,users.role');
        $this->db->from('student_basic_details');
        $this->db->join('users', 'student_basic_details.student_id = users.user_id', 'LEFT');
        $this->db->where('users.role', 'parents');
		$this->db->where('users.status', 'active');
        $query = $this->db->get();
        return $query->result_array();
    }
	
	
	public function get_students_data($studentid) {
        $this->db->select("first_name,middle_name,last_name,profile_photo,st_class,section");
        $this->db->from("student_basic_details");
        $this->db->where('student_id', $studentid);
        $query = $this->db->get();
        return $query->row();
    }
	public function get_fees_record($student_id) {
        
		$this->db->select('student_fees.*,staff_basic_details.first_name,staff_basic_details.last_name');
        $this->db->from('student_fees');
        $this->db->join('staff_basic_details', 'student_fees.cashier_id = staff_basic_details.id','LEFT');
		$this->db->where('student_fees.student_id', $student_id);
        
        $query = $this->db->get();
        return $query->result_array();
    }
	public function add_student_fees($student_id){
		$academic_year = date('Y').'-'.date('Y', strtotime("+1 year"));
		
        $query = $this->db->get_where('student_fees', array('student_id' => $student_id,'academic_year'=>$academic_year));
        $installment = $query->num_rows() + 1;
        $cashier_id = $_SESSION['user_id'];
        $data = array(	
						'student_id' => $student_id, 
						'date' => date('Y-m-d'),
						'cashier_id' => $cashier_id, 
						'academic_year' => $academic_year,
						'installment_no'=>$installment,
						'fees_amount'=>$this->input->post('amount'),
						'payment_mode'=>$this->input->post('payment_mode'),
						'transaction_no'=>$this->input->post('transaction_no')
					);
		if($this->db->insert('student_fees', $data)){
			return 'Fess paid sucessfully!';
		}else{
			return 'Something went wrong!';
		}
    }
	public function get_all_events() {
	    $this->db->order_by('event_id','DESC');
        $query = $this->db->get('event_management');
        return $query->result_array();
    }
	public function get_event_detail($event_id) {
        $query = $this->db->get_where('event_management', array('event_id' => $event_id));
        return  $query->row();
    }
	
	public function get_student_data($studentid) {
        $basicdetails = $this->get_basic_details($studentid);
        $address = $this->get_address($studentid);
        $profile = $this->get_profile($studentid);
        $parentsdetail = $this->get_parents_detail($studentid);
        $previouinstitute = $this->get_previous_institute($studentid);
        $medicaldetails = $this->get_medical_details($studentid);
        $final_data = array_merge($basicdetails, $address, $profile, $parentsdetail, $previouinstitute, $medicaldetails);
        $_SESSION['temp_student_data'] = $final_data;
        return $final_data;
    }
    public function get_basic_details($studentid) {
        $query = $this->db->get_where('student_basic_details', array('student_id' => $studentid));
        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return array();
        }
    }
    public function get_address($studentid) {
        $query = $this->db->get_where('student_address', array('student_id' => $studentid));
        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return array();
        }
    }
    public function get_profile($studentid) {
        $query = $this->db->get_where('student_profile', array('student_id' => $studentid));
        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return array();
        }
    }
    public function get_parents_detail($studentid) {
        $query = $this->db->get_where('student_parent_details', array('student_id' => $studentid));
        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return array();
        }
    }
    public function get_previous_institute($studentid) {
        $query = $this->db->get_where('student_previous_institute', array('student_id' => $studentid));
        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return array();
        }
    }
    public function get_medical_details($studentid) {
        $query = $this->db->get_where('student_medical_details', array('student_id' => $studentid));
        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return array();
        }
    }
	//UPDATE STUDENT DATA
    public function update_student_details($studentid, $table_name, $data) {
        if (count($data) > 0) {
            $query = $this->db->query("select * from  $table_name where student_id  = $studentid");
            if ($query->num_rows() > 0) {
                $this->db->set($data);
                $this->db->where('student_id', $studentid);
                $this->db->update($table_name);
                return "Data Update Successfully";
            } else {
                $data = array_merge($data, array('student_id' => $studentid));
                $this->db->insert($table_name, $data);
                return "Data Update Successfully";
            }
        } else {
            return 'No Data To Update';
        }
    }
	
	//DOWNLOAD STUDENT IMPORT TEMPLATE
    public function student_basic_details_template() {
        $query = $this->db->query("SELECT student_id,first_name,middle_name,last_name,gender,date_of_birth,parent_number,parent_email,adhar_no,registration_no,admission_number,academic_year,admission_date,st_class,section FROM student_basic_details ORDER BY student_id DESC LIMIT 1");
        $delimiter = ",";
        $newline = "\r\n";
        $data = $this->dbutil->csv_from_result($query, $delimiter, $newline);
        force_download('student_basic_details.csv', $data);
    }
    public function student_address_template() {
        $query = $this->db->query("SELECT student_id,l_house_no,l_street,l_area,l_city,l_tahshil,l_district,l_state,l_country,l_zip,p_house_no,p_street	p_area,p_city,p_tahshil,p_district,p_state,p_country,p_zip FROM student_address ORDER BY student_id DESC LIMIT 1");
        $delimiter = ",";
        $newline = "\r\n";
        $data = $this->dbutil->csv_from_result($query, $delimiter, $newline);
        force_download('student_address.csv', $data);
    }
    public function student_parent_template() {
        $query = $this->db->query("SELECT student_id,father_name,father_occupation,mother_name,mother_occupation,guardian_name,guardian_occupation,contact_office,contact_home,mother_mobile,mother_email FROM student_parent_details ORDER BY student_id DESC LIMIT 1");
        $delimiter = ",";
        $newline = "\r\n";
        $data = $this->dbutil->csv_from_result($query, $delimiter, $newline);
        force_download('student_parent_details.csv', $data);
    }
    public function student_previous_school_details() {
        $query = $this->db->query("SELECT student_id,institute_name,class_name,previous_academic_year,percentage,reason_to_leave FROM student_previous_institute ORDER BY student_id DESC LIMIT 1");
        $delimiter = ",";
        $newline = "\r\n";
        $data = $this->dbutil->csv_from_result($query, $delimiter, $newline);
        force_download('student_previous_institute.csv', $data);
    }
    public function student_medical_template() {
        $query = $this->db->query("SELECT student_id,blood_group,height,weight,medical_history FROM student_medical_details ORDER BY student_id DESC LIMIT 1");
        $delimiter = ",";
        $newline = "\r\n";
        $data = $this->dbutil->csv_from_result($query, $delimiter, $newline);
        force_download('student_medical_details.csv', $data);
    }
    public function student_profile_template() {
        $query = $this->db->query("SELECT student_id,religion,caste,category,family_income,number_of_sibling,interest,hobbies FROM student_profile ORDER BY student_id DESC LIMIT 1");
        $delimiter = ",";
        $newline = "\r\n";
        $data = $this->dbutil->csv_from_result($query, $delimiter, $newline);
        force_download('student_profile.csv', $data);
    }
    public function student_usernames_template() {
        $query = $this->db->query("SELECT user_id,username,password,role FROM users ORDER BY sr_no DESC LIMIT 1 ");
        $delimiter = ",";
        $newline = "\r\n";
        $data = $this->dbutil->csv_from_result($query, $delimiter, $newline);
        force_download('student_usernames_template.csv', $data);
    }
	public function upload_student_basic_details($column_values) {
        if ($this->db->query("INSERT INTO student_basic_details(student_id,first_name,middle_name,last_name,gender,date_of_birth,parent_number,parent_email,adhar_no,registration_no,admission_number,academic_year,admission_date,st_class,section) VALUES $column_values;")) {
            $message = "Data Imported Successfully!";
        } else {
            $message = "Data not imported due to some error!";
        }
        return $message;
    }
    public function upload_student_address($column_values) {
        if ($this->db->query("INSERT INTO student_address (student_id,l_house_no,l_street,l_area,l_city,l_tahshil,l_district,l_state,l_country,l_zip,p_house_no,p_street	p_area,p_city,p_tahshil,p_district,p_state,p_country,p_zip) VALUES $column_values;")) {
            $message = "Data Imported Successfully!";
        } else {
            $message = "Data not imported due to some error!";
        }
        return $message;
    }
    public function upload_student_parent_details($column_values) {
        if ($this->db->query("INSERT INTO student_parent_details (student_id,father_name,father_occupation,mother_name,mother_occupation,guardian_name,guardian_occupation,contact_office,contact_home,mother_mobile,mother_email) VALUES $column_values;")) {
            $message = "Data Imported Successfully!";
        } else {
            $message = "Data not imported due to some error!";
        }
        return $message;
    }
    public function upload_previous_school_details($column_values) {
        if ($this->db->query("INSERT INTO student_previous_institute(student_id,institute_name,class_name,previous_academic_year,percentage,reason_to_leave) VALUES $column_values;")) {
            $message = "Data Imported Successfully!";
        } else {
            $message = "Data not imported due to some error!";
        }
        return $message;
    }
    public function upload_student_medical_details($column_values) {
        if ($this->db->query("INSERT INTO student_medical_details(student_id,blood_group,height,weight,medical_history) VALUES $column_values;")) {
            $message = "Data Imported Successfully!";
        } else {
            $message = "Data not imported due to some error!";
        }
        return $message;
    }
    public function upload_student_profile_details($column_values) {
        if ($this->db->query("INSERT INTO student_profile(student_id,religion,caste,category,family_income,number_of_sibling,interest,hobbies) VALUES $column_values;")) {
            $message = "Data Imported Successfully!";
        } else {
            $message = "Data not imported due to some error!";
        }
        return $message;
    }
    public function upload_student_usernames($column_values) {
        if ($this->db->query("INSERT INTO users (user_id,username,password,role) VALUES $column_values;")) {
			$message = "Data Imported Successfully!";
			$this->db->select("sr_no,password,username");
			$query = $this->db->get('users');
			$result = $query->result_array();
			foreach($result as $sr_no){
				$password = $sr_no['password'];
				$hashpassword = password_hash($password, PASSWORD_DEFAULT);
				$this->db->set("password",$hashpassword);
				$this->db->where("sr_no",$sr_no['sr_no']);
				$this->db->update('users');
			}
        } else {
            $message = "Data not imported due to some error!";
        }
        return $message;
    }
	//Communication Portal
	public function get_messangers_list(){
		$user_name = $_SESSION['username'];
		$this->db->order_by('message_date','DESC');
		$query = $this->db->get_where('message',array('message_to'=>$user_name));
		$temp_data  = $query->result_array();
		
		foreach($temp_data as $data){
			$username = $data['message_from'];
			$message_id = $data['message_id'];
			$subject = $data['subject'];
			
			$this->db->select('user_id');
			$query = $this->db->get_where('users',array('username'=>$username));
			$result = $query->row();
			$userid = $result->user_id;
			
			if(substr($username,strlen($_SESSION['sch_code']),-6) == 'T' || substr($username,strlen($_SESSION['sch_code']),-6)== 'S' || substr($username,strlen($_SESSION['sch_code']),-6)== 'M'){
				$table = 'staff_basic_details';
				$field = 'id';
			}
			if(substr($username,strlen($_SESSION['sch_code']),-6) == 'P'){
				$table = 'student_basic_details';
				$field = 'student_id';
			}
			
			$this->db->select("first_name,last_name");
			$query = $this->db->get_where($table,array($field=>$userid));
			$names = $query->row();
			$first_name = $names ->first_name;
			$last_name	= $names ->last_name;
			
			$query = $this->db->get_where("message",array('message_from'=>$username,'message_status'=>'unread'));
			$message_count = $query->num_rows();
			$colors = array('b-success', 'b-primary', 'b-warning', 'b-info', 'b-complete', 'b-danger');
			$final_data[] = array(
									'username'   => $username,
									'first_name' => $first_name,
									'last_name'	 => $last_name,
									'message_count' => $message_count,
									'message_id' => $message_id,
									'subject'	=> 	$subject,
									'color'	=> $colors[array_rand($colors)]
								);
		}
		return $final_data;
	}
	
	public function get_unread_message_count(){
		$user_name = $_SESSION['username'];
		$query = $this->db->get_where('message',array('message_to'=>$user_name,'message_status'=>'unread'));
		return $query->num_rows();
	}
	public function get_sent_message_list(){
		$user_name = $_SESSION['username'];
		$this->db->order_by('message_date','DESC');
		$query = $this->db->get_where('message',array('message_from'=>$user_name));
		$temp_data = $query->result_array();

		foreach($temp_data as $data){
			$username = $data['message_from'];
			$message_to = $data['message_to'];
			
			$message_id = $data['message_id'];
			$subject = $data['subject'];
			
			$this->db->select('user_id');
			$query = $this->db->get_where('users',array('username'=>$message_to));
			$result = $query->row();
			$userid = $result->user_id;
			
			if(substr($message_to,strlen($_SESSION['sch_code']),-6) == 'T' || substr($username,strlen($_SESSION['sch_code']),-6)== 'S' || substr($username,strlen($_SESSION['sch_code']),-6)== 'M'){
				$table = 'staff_basic_details';
				$field = 'id';
			}
			if(substr($message_to,strlen($_SESSION['sch_code']),-6) == 'P'){
				$table = 'student_basic_details';
				$field = 'student_id';
			}
			
			$this->db->select("first_name,last_name");
			$query = $this->db->get_where($table,array($field=>$userid));
			$names = $query->row();
			$first_name = $names ->first_name;
			$last_name	= $names ->last_name;
			
			$query = $this->db->get_where("message",array('message_from'=>$username,'message_status'=>'unread'));
			$message_count = $query->num_rows();
			$colors = array('b-success', 'b-primary', 'b-warning', 'b-info', 'b-complete', 'b-danger');
			$final_data[] = array(
									'username'   => $username,
									'first_name' => $first_name,
									'last_name'	 => $last_name,
									'message_count' => $message_count,
									'message_id' => $message_id,
									'subject'	=> 	$subject,
									'color'	=> $colors[array_rand($colors)]
								);
		}
		return $final_data;
	}
	public function get_single_message($messageid){
		
		$this->db->set('message_status','read');
		$this->db->where('message_id',$messageid);
		$this->db->update('message');
		
		$query = $this->db->get_where('message',array('message_id'=>$messageid));
		$temp_data = $query->row();
		$username = $temp_data->message_from;
		
				
		$this->db->select('user_id');
		$query = $this->db->get_where('users',array('username'=>$username));
		$result = $query->row();
		$userid = $result->user_id;
		
			if(substr($username,strlen($_SESSION['sch_code']),-6) == 'T' || substr($username,strlen($_SESSION['sch_code']),-6)== 'S' || substr($username,strlen($_SESSION['sch_code']),-6)== 'M'){
				$table = 'staff_basic_details';
				$field = 'id';
			}
			if(substr($username,strlen($_SESSION['sch_code']),-6) == 'P'){
				$table = 'student_basic_details';
				$field = 'student_id';
			}
			
			$this->db->select("first_name,last_name");
			$query = $this->db->get_where($table,array($field=>$userid));
			$names = $query->row();
			$first_name = $names ->first_name;
			$last_name	= $names ->last_name;
		
		return array_merge((array)$temp_data,(array)$names);
	}
	public function reply_to($message_data){
		$message_from = $_SESSION['username'];
		$replay_to = $message_data->message_from;
		$parent_message = $message_data->parent_message;
		$subject = $message_data->subject;
		$message = $message_data->message;
		$data = array(
						'message_to'  	=>  $replay_to,
						'message_from'  =>  $message_from,
						'parents_message'  =>  $parent_message,
						'subject'		=> 'Re:' . $subject,
						'message'		=>  $message
					);
		$this->db->insert('message',$data);
		return "Message Sent!";
	}
	public function send_new_message($message_data){
		$message_from = $_SESSION['username'];
		$message_to = $message_data->message_to;
		$subject = $message_data->subject;
		$message = $message_data->message;
	
		for($i=0;$i<count($message_to);$i++){
				$data = array(
							'message_to'  	=> $message_to[$i],
							'message_from'  => $message_from,
							'subject'		=> $subject,
							'message'		=> $message
						);
				$this->db->insert('message',$data);
		}
		return "Message Sent mymodel messgae!";
	}
	public function send_new_message_to_all($message_data){
		$message_from = $_SESSION['username'];
		$message_to = $message_data->message_to;
		$subject = $message_data->subject;
		$message = $message_data->message;
		
		for($i=0;$i<count($message_to);$i++){
				$data = array(
							'message_to'  	=> $message_to[$i],
							'message_from'  => $message_from,
							'subject'		=> $subject,
							'message'		=> $message
						);
				$this->db->insert('message',$data);
		}
		return "Message Sent!";
	}
	
	
	public function get_send_to(){
		$username = $_SESSION['username'];
		$user_id = $_SESSION['user_id'];
		$final_data = array();
		$temp_data = array();
		if(substr($username,strlen($_SESSION['sch_code']),-6) == 'T'){
			$table = 'student_basic_details';
			$prefix= $_SESSION['sch_code'] . 'P-';
			$field = 'student_id';
			$this->db->select("$field,first_name,middle_name,last_name");
			$query = $this->db->get($table);
			$temp_data = $query->result_array();
		}
		if(substr($username,strlen($_SESSION['sch_code']),-6) == 'P'){
			$table = 'staff_basic_details';
			$prefix= $_SESSION['sch_code'] . 'T-';
			$field = 'id';
			$this->db->select("$field,first_name,middle_name,last_name");
			$this->db->where('designation','teacher');
			$query = $this->db->get($table);
			$temp_data = $query->result_array();
		}
		
		foreach($temp_data as $data){
			$final_data[]= array(
							'username'		=> $prefix.$data[$field],
							'first_name'  	=> $data['first_name'],
							'middle_name' 	=> $data['middle_name'],
							'last_name'	  	=> $data['last_name']
						);
		}
		return $final_data;
	}
	public function add_school_settings(){
		
		$file_to_upload = 'school_logo';
		$filename = 'logo';
		$path = './uploads/school_logo/';
		$filetypes = 'jpg|png|jpeg';
		$school_logo = $this->upload_file($file_to_upload,$filename,$path,$filetypes);
		$data = array(
						'school_name'  		=> $this->input->post('school_name'),
						'address'  			=> $this->input->post('address'),
						'email'				=> $this->input->post('email'),
						'phone'				=> $this->input->post('phone'),
						'mobile'			=> $this->input->post('mobile'),
						'fax'               => $this->input->post('fax'),
						'country'           => $this->input->post('country'),
						'school_code'       => $this->input->post('school_code'),
						'school_logo'       => $school_logo,
						'session_start_date'=> $this->input->post('session_start_date'),
						'session_end_date'  => $this->input->post('session_end_date'),
						'contact_person'    => $this->input->post('contact_person')
					);
		if($this->db->insert('school_option',$data)){
			return "School settings saved!";
		}else{
			return "Some error is occurred";
		}
	}
	public function add_account_settings(){
		$id = $this->get_staff_id();
		$staff_details =  array(
							'id'			=> $id,
							'first_name' 	=> $this->input->post('first_name'),
							'middle_name' 	=> $this->input->post('middle_name'),
							'last_name' 	=> $this->input->post('last_name'),
							'mobile_no' 	=> $this->input->post('mobile_no'),
							'email' 		=> $this->input->post('email'),
							'designation'	=> $this->input->post('designation'),
					);
		$users = array(
						'user_id'	=> $id,
						'username'	=> $this->input->post('username'),
						'password'	=> $this->input->post('password'),
						'role'		=> 'admin'
					);
				if($this->db->insert('staff_basic_details',$staff_details) && $this->db->insert('users',$users)){
					return "Account settings saved!";
				}else{
					return "Some error is occurred";
				}
	}
	public function get_school_data(){
		$query = $this->db->get_where('school_option',array('sr_no'=>1));
		return $query->row();
	}
	public function get_school_settings(){
		$this->db->select('school_name, country, address,email, phone, mobile, fax, contact_person, session_start_date, session_end_date, school_code, contact_person,school_logo');
		$query = $this->db->get_where('school_option',array('sr_no'=>1));
		
		$_SESSION['temp_school_setting'] = $query->row_array();
		return $query->row();
	}
	public function update_school_settings($data){
		if(count($data)>0){
			$this->db->set($data);
			$this->db->where('sr_no',1);
			$this->db->update('school_option');
			$message  = "School settings Updated!";
		}else{
			$message  = "Nothing to update!";
		}
		return $message;
	}
	public function change_password(){
		$new_password = $this->input->post('new_password');
		$username = $_SESSION['username'];
		$user_id = $_SESSION['user_id'];
		$this->db->set(array('password'=>$new_password));
		$this->db->where('username',$username);
		$this->db->where('user_id ',$user_id );
		if($this->db->update('users')){
			return "Your Pasword is change";
		}else{
			return "Your Pasword is not change";
		}
	}
	public function get_country_name(){
		$query = $this->db->get('country_name');
		return $query->result_array();
	}
	 //DASHBOARD DATA
    public function get_total_student_present() {
        $this->db->select('present_student_id');
        $query = $this->db->get_where('student_attendance', array('attendance_date' => date('Y-m-d')));
		$count = $query->num_rows();
		if($count>0){
			$total = $query->result_array();
			$total_student = 0;
			foreach ($total as $student) {
				$total_student = $total_student + count(explode(",", $student['present_student_id']));
			}
			return $total_student;
		}else{
			return 'NULL';
		}
    }
    public function get_total_staff_present() {
        $this->db->select('present_staff_id');
        $query = $this->db->get_where('staff_attendance', array('attendance_date' => date('Y-m-d')));
		$count = $query->num_rows();
		if($count>0){
			$total = $query->result_array();
			$total_staff = 0;
			foreach ($total as $staff) {
				$total_staff = $total_staff + count(explode(",", $staff['present_staff_id']));
			}
			return $total_staff;
		}else{
			return 'NULL';
		}
    }
    public function get_total_student() {
        $query = $this->db->get('student_basic_details');
        return $query->num_rows();
    }
    public function get_total_staff() {
        $query = $this->db->get('staff_basic_details');
        return $query->num_rows();
    }
	public function get_publish_news() {
		$this->db->order_by('sr_no','DESC');
        $query = $this->db->get('news');
		if($query->num_rows()>0){
			return $query->result_array();
		}else{
			return 'No news published';
		}	
    }
    public function get_publish_circulars() {
		$this->db->order_by('sr_no','DESC');
        $query = $this->db->get('circulars');
		if($query->num_rows()>0){
			return $query->result_array();
		}else{
			return 'No circulars available';
		}
    }
    public function get_single_circulars($sr_no) {
        $query = $this->db->get_where('circulars', array('sr_no' => $sr_no));
        return $query->row();
    }
    public function get_single_news($sr_no) {
        $query = $this->db->get_where('news', array('sr_no' => $sr_no));
        return $query->row();
    }
	
	
	//Add Students Module
	public function add_students() {
		$flag = 0;
        $student_id = $this->input->post('student_id');
        $username = $_SESSION['sch_code'].'P-' . $student_id;
			
		$filename = $student_id;
		$path = './uploads/student_photo/';
		$filetypes = 'jpg|png|jpeg';
		
		$file_to_upload = 'profile_photo';
        $stud_profile_photo = $this->upload_file($file_to_upload, $filename, $path, $filetypes);
		
		$file_to_upload = 'family_photo';
        $stud_family_photo = $this->upload_file($file_to_upload, $filename, $path, $filetypes);
       
        $student_basic_details = array('first_name' => ucwords(strtolower($this->input->post('first_name'))), 'middle_name' =>  ucwords(strtolower($this->input->post('middle_name'))), 'last_name' =>  ucwords(strtolower($this->input->post('last_name'))), 'gender' => $this->input->post('gender'), 'date_of_birth' => $this->input->post('date_of_birth'), 'parent_number' => $this->input->post('parent_number'), 'parent_email' => $this->input->post('parent_email'), 'adhar_no' => $this->input->post('adhar_no'), 'profile_photo' => $stud_profile_photo, 'family_photo' => $stud_family_photo, 'registration_no' => $this->input->post('registration_no'), 'admission_number' => $this->input->post('admission_number'), 'academic_year' => $this->input->post('academic_year'), 'admission_date' => $this->input->post('admission_date'), 'st_class' => $this->input->post('st_class'), 'section' => $this->input->post('section'),);
        $this->db->insert('student_basic_details', $student_basic_details);
        $users = array('user_id' => $student_id, 'username' => $username, 'password' => $username, 'role' => 'parents');
      
		 if ($this->db->insert('users', $users)) {
                $flag = 1;
            }
		
        $student_profile = array('student_id' => $student_id, 'religion' => $this->input->post('religion'), 'caste' => $this->input->post('caste'), 'category' => $this->input->post('category'), 'family_income' => $this->input->post('family_income'), 'number_of_sibling' => $this->input->post('number_of_sibling'), 'interest' => $this->input->post('interest'), 'hobbies' => $this->input->post('hobbies'),);
        $this->db->insert('student_profile', $student_profile);
        $student_address = array('student_id' => $student_id, 'l_house_no' => $this->input->post('l_house_no'), 'l_street' => $this->input->post('l_street'), 'l_city' => $this->input->post('l_city'), 'l_area' => $this->input->post('l_area'), 'l_tahshil' => $this->input->post('l_tahshil'), 'l_district' => $this->input->post('l_district'), 'l_state' => $this->input->post('l_state'), 'l_country' => $this->input->post('l_country'), 'l_zip' => $this->input->post('l_zip'), 'p_house_no' => $this->input->post('p_house_no'), 'p_street' => $this->input->post('p_street'), 'p_area' => $this->input->post('p_area'), 'p_city' => $this->input->post('p_city'), 'p_tahshil' => $this->input->post('p_tahshil'), 'p_district' => $this->input->post('p_district'), 'p_state' => $this->input->post('p_state'), 'p_country' => $this->input->post('p_country'), 'p_zip' => $this->input->post('p_zip'));
        $this->db->insert('student_address', $student_address);
        $student_previous_institute = array('student_id' => $student_id, 'institute_name' => $this->input->post('institute_name'), 'class_name' => $this->input->post('class_name'), 'previous_academic_year' => $this->input->post('previous_academic_year'), 'percentage' => $this->input->post('percentage'), 'reason_to_leave' => $this->input->post('reason_to_leave'));
        $this->db->insert('student_previous_institute', $student_previous_institute);
        $student_parent_details = array('student_id' => $student_id, 'father_name' => $this->input->post('father_name'), 'father_occupation' => $this->input->post('father_occupation'), 'mother_name' => $this->input->post('mother_name'), 'mother_occupation' => $this->input->post('mother_occupation'), 'guardian_name' => $this->input->post('guardian_name'), 'guardian_occupation' => $this->input->post('guardian_occupation'), 'contact_office' => $this->input->post('contact_office'), 'contact_home' => $this->input->post('contact_home'), 'mother_mobile' => $this->input->post('mother_mobile'), 'mother_email' => $this->input->post('mother_email'));
        $this->db->insert('student_parent_details', $student_parent_details);
        $student_medical_details = array('student_id' => $student_id, 'blood_group' => $this->input->post('blood_group'), 'height' => $this->input->post('height'), 'weight' => $this->input->post('weight'), 'medical_history' => $this->input->post('medical_history'));
        $this->db->insert('student_medical_details', $student_medical_details);
        $email_to = $this->input->post('email');
        
		if ($flag == 1) {
			$body = "";
			$body.= "iSyncERP Account Details\r\n";
			$body.= "Username : " . $username . "\r\n";
			$body.= "Password : " . $username . "\r\n";
			$body.= "Login URL : " . base_url();
			$subject = "iSyncERP Account Details";
			$from = "School";
			//$this->send_email($email_to, $body, $subject, $from);
		}
        return "Student Added successfully!";
    }
    public function get_attendace_record_month() {
        $sid = $this->input->post('user_id');
        $month = date('m', strtotime($this->input->post('date')));
        $year = date('Y', strtotime($this->input->post('date')));
        $stu_data = $this->get_class_section_id($sid);
        $class = $stu_data["st_class"];
        $section = $stu_data["section"];
        $working_day = $this->db->query("SELECT * FROM `student_attendance` WHERE MONTH(`attendance_date`) = '$month' AND YEAR(`attendance_date`) = '$year' AND stu_class = '$class' AND class_section = '$section' ORDER BY attendance_id ASC")->result_array();
        // $data['working_day'] = $working_day;
        $present_day = $this->db->query("SELECT attendance_id FROM `student_attendance` WHERE MONTH(`attendance_date`) = '$month' AND YEAR(`attendance_date`) = '$year' AND stu_class = '$class' AND class_section = '$section' AND  `present_student_id` LIKE '%$sid%' ORDER BY attendance_id ASC")->result_array();
        
        if(empty($present_day)){
                for ($i = 0;$i < count($working_day);$i++) {
                    $atten = 'Absent';
                    $data[] = array('data' => $working_day[$i], 'att' => $atten,);
                }

        }else{
            $j = 0;
                for ($i = 0;$i < count($working_day);$i++) {
                    if(empty($present_day[$j]['attendance_id'])){
                       $atten = 'Absent';
                    }else{
                        if ($present_day[$j]['attendance_id'] == $working_day[$i]['attendance_id']) {
                            $atten = 'Present';
                            $j++;
                        } else {
                            $atten = 'Absent';
                        }
                    }
                    
                    $data[] = array('data' => $working_day[$i], 'att' => $atten,);
                }
        }

        if(empty($data)){
            return array();
        }else{
            return $data;    
        }
    }
    public function get_class_section_id($student_id) {
        $query = $this->db->select('*')->from('student_basic_details')->where('student_id', $student_id)->get()->row_array();
        return $query;
    }
    
	
}
?>