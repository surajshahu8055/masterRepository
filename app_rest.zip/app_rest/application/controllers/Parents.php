<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Parents extends MY_Controller {
    public function __construct() {
        parent::__construct();
        //LOAD ALL REQUIRED MODEL
        $this->load->model('parent_model');
        // $check = $this->parent_model->check_login();
        // if ($check == 0) {
            // redirect('login');
        // }
    }
    
	
    
    public function attendance_for_dashboard_get() {
		$student_id = $this->uri->segment('3');
        $attendance_count = $this->parent_model->get_attendance_count($student_id);
        $working_days = $this->parent_model->get_working_days_count($student_id);
        $data = array(
						'attendance_count' =>$attendance_count,
						'working_days'=> $working_days,
						'absent_days' =>$working_days - $attendance_count 
					);
		$this->response($data);
    }
	
	 public function attendance_get() {
		$student_id = $this->uri->segment('3');
        $cd = $this->parent_model->get_class_section($student_id);
        if(!empty($cd)){
            $attendance_count = $this->parent_model->monthwise_attendance($student_id);
            $working_days = $this->parent_model->monthwise_working_days($cd->st_class,$cd->section);
            $j=0;
            if(count($working_days)>0){
                for($i=0;$i<count($working_days);$i++){
                    if($working_days[$i]['y']==$attendance_count[$j]['y'] && 
                    $working_days[$i]['m']==$attendance_count[$j]['m']){
                        $att = $attendance_count[$j]['days'];
                            if(isset($attendance_count[$j+1]))
                            {
                                $j++;
                            }
                    }else{
                        $att = 0;
                    }
                    $mon = date("F,Y" , strtotime($working_days[$i]['y'].'-'.$working_days[$i]['m']));
                    $ab = $working_days[$i]['days']-$att;
                $data[] = array(
                                'month'         => $mon,
                                'present_days' =>$att,
                                'absent_days' =>$ab,
                                'working_days'=> $working_days[$i]['days'], 
                            );
                }
            }else{
                $data = array();
            }
        }else{
                $data = array();
            }
		$this->response($data);
    }
	
    public function fees_record_get() {
        $student_id = $this->uri->segment('3');
        $total_school_fees = $this->parent_model->get_total_school_fees($student_id);
        $total_fees_paid = $this->parent_model->get_total_fees_paid($student_id);
        $balance_fees = $total_school_fees - $total_fees_paid;
		
		
		$data = array(
						'total_school_fees'=> (int)$total_school_fees,
						'total_fees_paid' => (int)$total_fees_paid,
						'balance_fees'=>$balance_fees
					);
		//$this->response(json_encode($total_school_fees));
	$this->response($data);
	
    }
	
	public function fees_record_log_get() {
        $student_id = $this->uri->segment('3');
        $fees_record = $this->parent_model->get_fees_record_student($student_id );
		
		$this->response($fees_record);
	
    }
    // public function exam_time_table() {
        // $data['controller_name'] = 'Parents';
        // $data['view'] = 'Exam Time Table';
        // $data['time_table'] = $this->parent_model->get_exam_time_table();
        // $data['page_name'] = 'parents/exam_time_table';
        // $this->load->view("isyncerp/template/dashboard", $data);
    // }
    public function view_class_time_table_get() {
         $data['controller_name'] = 'Parents';
         $data['view'] = 'Class Time Table';
         $data['time_table'] = $this->parent_model->get_class_time_table();
         $result = $this->parent_model->get_class_section();
         $data['class'] = $result->st_class;
         $data['section'] = $result->section;
         $data['page_name'] = 'parents/class_time_table';
         $this->load->view("isyncerp/template/dashboard", $data);
     }
     
     public function day_wise_time_table_get(){
         $student_id = $this->uri->segment('3');
         $day = $this->uri->segment('4');
         $data = $this->parent_model->day_wise_time_table($student_id, $day);
         $this->response($data);
     }
     
    public function feedback_get() {
		$student_id = $this->uri->segment('3');
        $data = $this->parent_model->get_my_feedback($student_id);
		$this->response($data);
    }
    
    public function assignment_get() {
        $student_id = $this->uri->segment('3');
        $data = $this->parent_model->get_assignement($student_id);
		$this->response($data);
    }
    public function view_assignment_attachment() {
        $fileName = $this->uri->segment('3'); // GET FILE NAME
        $filepath = file_get_contents(base_url() . 'uploads/assignment_files/' . $fileName);
        force_download($fileName, $filepath); // start download`
        
    }
    public function homework_get() {
        $student_id = $this->uri->segment('3');
        $data= $this->parent_model->get_homework($student_id);
		$this->response($data);
    }
    //NEWS AND circulars
    public function view_news_get() {
		$data = $this->parent_model->get_publish_news();
        $this->response($data);
    }
    public function view_circulars_get() {
        $data = $this->parent_model->get_publish_circulars();
        $this->response($data);
    }
	public function read_circulars_get() {
        $sr_no = $this->uri->segment('3');
        $data = $this->staff_model->get_single_circulars($sr_no);
        $this->response($data);
    }
    public function read_news_get() {
        $sr_no = $this->uri->segment('3');
        $data['news'] = $this->staff_model->get_single_news($sr_no);
        $this->response($data);
    }
    //NEWS AND CIRCULARS
    public function view_event_get() {
        $data = $this->parent_model->get_all_events();
        $this->response($data);
    }
    public function view_event_detail_get($event_id) {
		$data = $this->parent_model->get_event_detail($event_id);
		$this->response($data);
    }
	
    public function enroll_for_event_get() {
		$event_id  = $this->uri->segment('3');
		$student_id = $this->uri->segment('4');
        $result = $this->parent_model->enroll_for_event($event_id,$student_id);
        $this->response($result);
    }
	
    public function view_daily_log_get() {
		$student_id = $this->uri->segment('3');
        $data = $this->parent_model->get_daily_log($student_id);
        $this->response($data);
    }
    public function profile_get() {
        $student_id = $this->uri->segment('3');
        $data = $this->parent_model->get_student_data($student_id);
        $this->response($data);
    }

    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    // to get exam wise report 
    public function report_card_post()
    {
        $student_id =  $this->input->post('student_id');
        $exam_name  =  $this->input->post('exam_name');
        $data = $this->parent_model->get_report_card_examwise($student_id, $exam_name);
    	$this->response($data);
    }
    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	public function get_class_section_get(){
		$student_id = $this->uri->segment('3');
        $data = $this->parent_model->get_class_student($student_id);
        $this->response($data);
	}
	
	public function get_class_student_get(){
		$student_id = $this->uri->segment('3');
        $data = $this->parent_model->get_class_student($student_id);
        $this->response($data);
	}

    public function search_result_get() {
        $student_id = $this->uri->segment('3');
        $class = $this->uri->segment('4');
        $section = $this->uri->segment('5');
        $data = array(
            'student_details' => $this->parent_model->get_student_details(),
            'getStudent_result' => $this->parent_model->getAllresultByID(),
            'self_attendance' => $this->parent_model->get_current_acadmic_attendance(),
            'student_address' => $this->parent_model->get_student_address(),
            'student_parent_details' => $this->parent_model->get_student_parent_details(),
            'school_data' => $this->parent_model->get_school_settings()
        );
        $this->response($data);
        
    }
}
?>