<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Teacher extends MY_Controller {
    public function __construct() {
        parent::__construct();
        //LOAD ALL REQUIRED MODEL
        $this->load->model('teacher_model');
        // $check = $this->teacher_model->check_login();
        // if ($check == 0) {
            // redirect('login');
        // }
    }
    // public function get_events() {
        // $query = $this->db->get('events');
        // $data = $query->result_array();
        // echo json_encode($data);
    // }
    public function attendance_get() {
        $teacher_id = $this->uri->segment('3');
        $class_details = $this->teacher_model->get_class_details($teacher_id);
        $students_name = $this->teacher_model->get_student_names($class_details);
		$data = array(
						'class' => $class_details->class_assigned,
						'section' => $class_details->section_assigned,
						'students_name' => $students_name
					);
		$this->response($data);
    }
	
    public function mark_attendance_post() {
        $result = $this->teacher_model->mark_student_attendance();
		$this->response($result);	
    }
    // public function result() {
        // $teacher_id = $this->uri->segment('3');
        // $class_details = $this->teacher_model->get_class_details($teacher_id);
		// $class = $class_details->class_assigned;
		
		// if($class_details!='NULL'){
			// $data['class'] = $class;
			// $data['students_name'] = $this->teacher_model->get_student_names($class_details);
			// $data['flag'] = 1;
		// }else{
			// $data['flag'] = 0;
		// }
       
        // $data['page_name'] = 'teacher/add_result';
        // $this->load->view("isyncerp/template/dashboard", $data);
    // }
    // public function add_result() {
		
		// $subject = $this->input->post('subject[]');
		// $marks =  $this->input->post('marks[]');
		
		// $subject_grades = $this->input->post('subject_grades[]');
		// $grades = $this->input->post('grade[]');
		
		// $count_subject_grades =  count($subject_grades);
		// $count_grades =  count($grades);
		
		// $count_subject = count($subject);
		// $count_marks = count($marks);
		
		// $exam_name = $this->input->post('exam_name');
		// $out_of_marks = '';
		// if($exam_name == 'PA1' || $exam_name == 'PA2'){
			// $out_of_marks = 20;
		// }elseif($exam_name == 'HYE' || $exam_name == 'FE'){
			// $out_of_marks = 80;
		// }
		// $result_grade ='';
		
		// if($count_subject == $count_marks){
			// for($i=0;$i<$count_subject;$i++) {
				// $data_marks = array(
							// 'studentid' => $this->input->post('studentid'),
							// 'class' => $this->input->post('class'),
							// 'exam_name' => $exam_name,
							// 'subject' => $subject[$i], 
							// 'marks_obtained'=> $marks[$i],
							// 'out_of_marks'=> $out_of_marks 
							// );
					// $result_marks = $this->teacher_model->add_marks($data_marks);		
			// }	
		// }
		// if($count_subject_grades == $count_grades){
			
			// for($i=0;$i<$count_subject_grades;$i++) {
			// $data_grade = array(
							// 'studentid' => $this->input->post('studentid'),
							// 'class' => $this->input->post('class'),
							// 'exam_name' => $exam_name,
							// 'subject' => $subject_grades[$i], 
							// 'grade_obtained'=> $grades[$i],
						// );
					// $result_grade = $this->teacher_model->add_grades($data_grade);		
			// }	
		// }
		// $result = $result_marks.' & '.$result_grade;
        // $this->session->set_flashdata('success_message',$result);
        // redirect('teacher/result');
    // }
    
    // public function view_result() {
	
        // $data['controller_name'] = 'Teacher';
        // $data['view'] = 'View Result';
        // $teacher_id = $_SESSION['user_id'];
        // $class_details = $this->teacher_model->get_class_details($teacher_id);
        // $data['students_name'] = $this->teacher_model->get_student_names($class_details);
		
        // $data['class_details'] = $class_details;
        // $data['page_name'] = 'teacher/view_result';
        // $this->load->view("isyncerp/template/dashboard", $data);
    // }
    // public function search_result() {
        // $data['controller_name'] = 'Teacher';
        // $data['view'] = 'Search Result';
		// $student_id = $this->uri->segment('3');
		// $class = $this->uri->segment('4');
		
		// $result = $this->teacher_model->get_student_result_studentid($student_id,$class);
        // $grades = $this->teacher_model->get_student_grade_studentid($student_id,$class);
        // if ($result == 'false') {
            // $data['result_status'] = 'false';
            // $this->session->set_flashdata('success_message','Result not found');
			// redirect('teacher/view_result');
        // } else {
            // $data['result_status'] = 'true';
            // $data['student_marks'] = $result;
            // $data['student_grades'] = $grades;
            // $data['student_details'] = $this->teacher_model->get_student_details($student_id);
			// $data['school_data'] = $this->teacher_model->get_school_settings();
            // $data['page_name'] = 'teacher/search_result';
            // $this->load->view("isyncerp/template/dashboard", $data);
        // }
        
    // }
    //FEEDBACK
    public function feedback_get() {
        $teacher_id = $this->uri->segment('3');
        $class_details = $this->teacher_model->get_class_details($teacher_id);
        $data = $this->teacher_model->get_student_names($class_details);
        $this->response($data);
    }
    public function add_feedback_post() {
        $data = $this->teacher_model->add_feedback();
        $this->response($data);
    }
    public function view_feedback_get() {
        $teacher_id = $this->uri->segment('3');
        $data = $this->teacher_model->get_student_feedback($teacher_id);
        $this->response($data);
    }
    
    public function assigned_classes_get(){
        $teacher_id = $this->uri->segment('3');
        $data = $this->teacher_model->get_assigned_classes($teacher_id);
        $this->response($data);
    }
    
    public function assigned_class_section_get(){
        $teacher_id = $this->uri->segment('3');
        $class_name = $this->uri->segment('4');
        $data = $this->teacher_model->get_assigned_class_section($teacher_id, $class_name);
        $this->response($data);
    }
    
    public function assigned_subjects_get(){
        $teacher_id = $this->uri->segment('3');
        $class_name = $this->uri->segment('4');
        $section = $this->uri->segment('5');
        $data = $this->teacher_model->get_assigned_subjects($teacher_id, $class_name, $section);
        $this->response($data);
    }
    
    //ASSIGNMENT
    public function subjects_get() {
       $data =  array (
			'sub_1_3'	=> array('English','Maths','Mental Maths','Hindi','Value Education','Computer','GK','Marathi'),
			'sub_4_5'	=> array('English','Hindi','Marathi','Science','Social Studies','Maths','Computer','GK','Value Education','Music and Dance'),
			'sub_6_12' => array('English','Hindi','Sanskrit','Maths','Science','Social Science','Computer','Music and Dance'),
			);
        $this->response($data);
    }
    public function add_assignment_post() {
	
       $result = $this->teacher_model->add_assignment();
	   $this->response($result);
    }
    public function view_assignment_get() {
		$teacher_id = $this->uri->segment('3');
        $data = $this->teacher_model->get_assignement($teacher_id);
		$this->response($data);
    }
    public function view_assignment_attachment() {
        $fileName = $this->uri->segment('3'); // GET FILE NAME
		$temp = explode('_',base_url());
        $filepath = file_get_contents($temp[0]. 'uploads/assignment_files/' . $fileName);
        force_download($fileName, $filepath); // start download`
    }
    //ASSIGNMENT
    //HOMEWORK
    
    public function add_homework_post() {
        $data = $this->teacher_model->add_homework();
		$this->response($data);
    }
    public function view_homework_get() {
		$teacher_id = $this->uri->segment('3');
        $data = $this->teacher_model->get_homework($teacher_id);
        $this->response($data);
    }
    //HOMEWORK
    
	
    //NEWS AND CIRCULARS
    public function view_event_get() {
		$teacher_id = $this->uri->segment('3');
        $data = $this->teacher_model->get_all_events();
        $this->response($data);
    }
    public function view_event_detail($event_id) {
     	$data['event'] = $this->teacher_model->get_event_detail($event_id);
		$this->load->view("isyncerp/template/event_model", $data);
    }
    //ENROLL EVENT
    public function enroll_for_event_get($event_id) {
		$teacher_id = $this->uri->segment('3');
		$event_id = $this->uri->segment('4');
        $data = $this->teacher_model->enroll_for_event($teacher_id,$event_id);
        $this->response($data);
    }
	
    //VIEW CLASSTIME TABLE
    public function class_time_table_post() {
		$class = $this->input->post('tt_class');
		$section = $this->input->post('section');
        $day =  $this->input->post('day');
		$data = $this->teacher_model->view_class_time_table($class, $section, $day);
		$this->response($data);
    }
	
    //DAILY LOG MODULE
    public function add_daily_log_post() {
        $data = $this->teacher_model->add_daily_log();
		$this->response($data);
    }
    public function view_daily_log_get() {
		$teacher_id = $this->uri->segment('3');
        $data = $this->teacher_model->get_daily_log($teacher_id);
      	$this->response($data);
    }
    
	/*START LEAVE MANAGER*/
	public function leaves_get() {
		$teacher_id = $this->uri->segment('3');
		$data = $this->teacher_model->get_my_leaves($teacher_id);
		$this->response($data);
    }
	public function apply_for_leave_post() {
		$teacher_id = $this->uri->segment('3');
        $result = $this->teacher_model->apply_for_leave($teacher_id);
		$this->response($result);
    }


    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% //
    // student attendance start
    
    public function view_student_attendance_post(){
        $search_by = $this->input->post('type');
        if($search_by!==""){
            if($search_by=="date"){
                $result = $this->teacher_model->get_student_attendance_daywise();
            }else if($search_by=="month"){
                $result = $this->teacher_model->get_student_attendance_by_month();
            }else if ($search_by=="student") {
                $result = $this->teacher_model->get_attendace_record_student();
            }
        } else {
            $result = array();
        }
        $this->response($result);
    }
    
    // student attendance end
    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% //

    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    public function view_teacher_profile_post()
    {
		//$teacher_id = $this->uri->segment('3');
        $staffid = array('id'=> $this->input->post('teacher_id'));
        $data['basic'] = $this->teacher_model->get_teacher_details($staffid);
        $address = $this->teacher_model->get_teacher_address($staffid);
        $data['basic']['local'] ="";
        $data['basic']['permanent'] ="";
        if($address !=""){
            $data['basic']['local'] =   $address["l_house_no"].' '.
                                        $address["l_street"].' '.  
                                        $address["l_area"].' '.
                                        $address["l_city"] .' '.       
                                        $address["l_tahshil"].' '.        
                                        $address["l_district"] .' '.       
                                        $address["l_state"].' '.
                                        $address["l_country"].' '.       
                                        $address["l_zip"];

        $data['basic']['permanent'] =   $address["p_house_no"].' '.
                                        $address["p_street"].' '.  
                                        $address["p_area"].' '.
                                        $address["p_city"] .' '.       
                                        $address["p_tahshil"].' '.        
                                        $address["p_district"] .' '.       
                                        $address["p_state"].' '.
                                        $address["p_country"].' '.       
                                        $address["p_zip"];
        }
        $data['education'] = $this->teacher_model->get_teacher_education($staffid);
        $this->response($data);   
    }
    // %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	public function class_teacher_details_post() {
        $teacher_id = $this->input->post('teacher_id');
        $class_details = $this->teacher_model->get_class_teacher_details($teacher_id);
        $this->response($class_details);
    }

    public function subject_teacher_details_post(){
        $teacher_id = $this->input->post('teacher_id');
        $class_details = $this->teacher_model->get_class_teacher_details($teacher_id);
        $subject_teacher = $this->teacher_model->get_subject_teacher($teacher_id);
        $data = array(
                    'class_teacher'   => $class_details,
                    'subject_teacher' => $subject_teacher,
                );
        $this->response($data);   
    }

    // public function subject_teacher_details_post(){
    //     $teacher_id = $this->input->post('teacher_id');
    //     $subject_teacher = $this->teacher_model->get_subject_teacher($teacher_id);
    //     $this->response($subject_teacher);   
    // }
    public function get_todays_leactures_get() {
        $teacher_id = $this->uri->segment('3');
        $result = $this->teacher_model->get_todays_leactures_get($teacher_id);
        $this->response($result);   
    }
}
?>