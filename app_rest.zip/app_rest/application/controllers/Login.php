<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends MY_Controller {
    public function __construct() {
        parent::__construct();
        //LOAD ALL REQUIRED MODEL
        $this->load->model('login_model');
    }
    
    public function check_user_post() {
		
		$username = $this->input->post("username");
        $password = $this->input->post("password");
		
        $check_user_table = $this->login_model->check_user_table();
        if ($check_user_table == 0) {
			$message = "Application don't have admin Please contact to school !";
			$data = array('error'=>$message,'logged_in' => FALSE);
			$this->response($data);
        }
        
        $result = $this->login_model->check_user($username, $password);
        if ($result == 1) {
            $user_data = $this->login_model->get_user_data($username);
            $user_id = $user_data->user_id;
            $user_role = $user_data->role;
            $user_deatils = $this->login_model->get_session_data($user_id, $user_role);
            
            //Get School Data
            $sch_data = $this->login_model->get_school_data();
            
			$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
			$domainName = $_SERVER['HTTP_HOST'].'/';
			$host =  $protocol.$domainName;;
			$first_login = ($user_data->first_login == "Yes") ? TRUE : FALSE;
			$data = array(
							'logged_in' => TRUE, 
							'username' => $username, 
							'user_role' => $user_role, 
							'user_id' => (int)$user_id,
							'first_name' => $user_deatils->first_name,
							'last_name' => $user_deatils->last_name,
							'profile_photo' => $user_deatils->profile_photo,
							'first_login' => $first_login,
							'sch_start_date' =>$sch_data->session_start_date,
							'sch_end_date' =>$sch_data->session_end_date, 
						);
			$this->response($data);
			
        } else {
			$message = "Invalid Credential";
			$data = array('error'=>$message,'logged_in' => FALSE);
			$this->response($data);
        }
    }
	
	public function force_password_change_post()
    {
    	$username = $this->input->post("username");
    	$password1 = $this->input->post("password_new");
    	$password2 = $this->input->post("password_conf_pass");
    	if($password1 == $password2){
    		if($this->login_model->force_password_change($username,$password1)){
    			$data = TRUE;
    		}else{
    			$data = FALSE;
    		}
    	}else{
    		$data = FALSE;
    	}
    	$this->response($data);
    }
}
?>