<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends MY_Controller {
    public function __construct() {
        parent::__construct();
        //LOAD ALL REQUIRED MODEL
        $this->load->model('admin_model');
    }
    public function view_subject_get() {
        $data= $this->admin_model->view_subject();
        $this->response($data);
    }
}
?>